---
title: "Map of Content — Constitutions Financières ONLYMORE Group"
date: 2026-05-13
type: moc
status: v1.0
author: Florent Gibert
group: ONLYMORE Group
vault_path: "00-Constitutions-Financieres/"
tags:
  - onlymore/moc
  - onlymore/moc/constitutions
  - onlymore/constitution/finance
---

# Map of Content — Constitutions Financières ONLYMORE Group

> [!info] Objet de ce MOC
> Point d'entrée unique vers la doctrine financière intégrale d'ONLYMORE Group. Les trois constitutions sont complémentaires et indissociables : aucune ne peut être appliquée sans les deux autres.

## Les trois constitutions financières

| Rang | Titre | Principe synthétique | Statut | Lien |
|---|---|---|---|---|
| 1ʳᵉ | Capital Sociétaire Inaliénable | Le capital apporté par les sociétaires ne peut jamais être consommé, liquidé ni redistribué en numéraire — il reste indéfiniment la propriété collective. | stub | [[2026-05-13-Capital-Societaire-Inalienable]] |
| 2ᵉ | Double Boucle Infinie ∞ Bourse-Lombard | Chaque dollar entrant est investi en bourse, le Lombard à 80% LTV est tiré dessus et réinjecté — facteur multiplicateur géométrique ×5. | stub | [[2026-05-13-Constitution-Double-Boucle-Infinie]] |
| 3ᵉ | Cascade Mutualiste SPV | Chaque dépôt mensuel constitue un SPV juridiquement isolé, indexé sur sa propre position bourse, négociant son propre Lombard avec sa propre banque privée. | draft v1.0 | [[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3]] |

## Chartes opérationnelles associées

| Titre | Objet | Statut | Lien |
|---|---|---|---|
| Charte Bienveillance CROWNIUM | Cadre éthique relation clubs-supporters-infrastructure fan capital, préservation 100% du capital sportif des clubs. | stub | [[2026-05-13-Charte-Bienveillance-CROWNIUM]] |
| Charte Fonds Services Suspendus | Doctrine d'affectation et de distribution des services suspendus (héritage caffè sospeso), traçabilité sociétaire-à-bénéficiaire. | stub | [[2026-05-13-Charte-Fonds-Services-Suspendus]] |

## Briefs et documents opérationnels liés

| Titre | Destinataire | Statut | Lien |
|---|---|---|---|
| Brief CFO João Almeida — Cascade SPV (mai 2026) | João Almeida (CFO) | stub enrichi | [[2026-05-13-Brief-CFO-Joao-Almeida-2026-05]] |

## Convention de vault

### Nommage de fichier

Format imposé : `YYYY-MM-DD-Titre-Kebab-Case.md`

- Date = date de rédaction initiale, jamais modifiée lors d'une version ultérieure
- Titre en kebab-case (mots séparés par tirets simples)
- Pas d'espaces, pas d'accents, pas de caractères spéciaux dans le nom de fichier
- Le titre lisible va dans le frontmatter `title:`

### Taxonomie de tags hiérarchique

| Tag | Usage |
|---|---|
| `#onlymore/constitution/finance` | Constitutions financières du groupe |
| `#onlymore/charte` | Chartes opérationnelles |
| `#onlymore/filiale/colhybri` | Documents touchant COLHYBRI |
| `#onlymore/filiale/crownium` | Documents touchant CROWNIUM |
| `#onlymore/filiale/dojuku-shingi` | Documents touchant DOJUKU SHINGI |
| `#onlymore/filiale/onlymore-finance` | Documents touchant ONLYMORE FINANCE |
| `#onlymore/filiale/plumaya` | Documents touchant PLUMAYA |
| `#onlymore/doctrine/lombard` | Doctrine crédit Lombard |
| `#onlymore/doctrine/spv` | Doctrine SPV / Special Purpose Vehicle |
| `#onlymore/doctrine/bourse` | Doctrine portefeuille bourse |
| `#onlymore/moc` | Maps of Content |
| `#onlymore/brief/cfo` | Briefs CFO |

### Statuts utilisés

| Statut | Définition |
|---|---|
| `stub` | Squelette créé, contenu à formaliser |
| `draft` | Rédaction en cours, non figée |
| `draft v1.0` | Première version complète, soumise à validation |
| `v1.0` | Version validée, en vigueur |
| `finalisé` | Version constitutionnelle figée, modifiable uniquement par signature conjointe CEO + CFO + Board Advisor |

---

*MOC institué le 13 mai 2026 — premier document de navigation du vault Obsidian ONLYMORE Group.*
