---
title: "Constitution Double Boucle Infinie ∞ Bourse-Lombard"
date: 2026-05-13
type: constitution-financiere
status: stub
author: Florent Gibert
group: ONLYMORE Group
vault_path: "00-Constitutions-Financieres/"
moc: "[[_MOC-Constitutions-Financieres]]"
aliases:
  - Constitution-Double-Boucle-Infinie
tags:
  - onlymore/constitution/finance
  - onlymore/doctrine/bourse
  - onlymore/doctrine/lombard
  - onlymore/filiale/colhybri
version: 0.1
related:
  - "[[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3]]"
  - "[[2026-05-13-Capital-Societaire-Inalienable]]"
---

# Constitution Double Boucle Infinie ∞ Bourse-Lombard

**2ᵉ Constitution Financière ONLYMORE Group.**

Chaque dollar entrant est investi en bourse. Le crédit Lombard à 80% LTV est tiré dessus et réinjecté intégralement. Le facteur multiplicateur géométrique attendu est de ×5, hors yield bourse et hors coût Lombard.

> [!warning] Statut : DRAFT — Document à formaliser
> Ce document est un stub. La doctrine complète Double Boucle Infinie reste à rédiger formellement, en cohérence avec la [[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3|Cascade Mutualiste SPV]] qui la distribue juridiquement.

## Référence parent

Voir [[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3|Cascade Mutualiste SPV — 3ᵉ Constitution]], notamment :

- Préambule (positionnement dans le triptyque constitutionnel)
- Partie III, sous-section *« Articulation avec la Double Boucle Infinie ∞ »*

## Éléments connus (extraits Cascade SPV)

- **Principe doctrinal** — Chaque dollar entrant est investi en bourse. Le Lombard à 80% LTV est tiré sur la position et réinjecté.
- **Facteur multiplicateur géométrique** — ×5.
- **Articulation avec Cascade SPV** — La Cascade n'annule pas la Double Boucle, elle la distribue géographiquement et juridiquement en SPV mensuels.
- **LTV cible** — 80% (Annexe 2 du doc parent).
- **Taux Lombard hypothèse 2026** — 4,5% / an.
- **Yield portefeuille cible** — 4% / an, atteint via mix actions dividendes (35%) + obligations IG (30%) + REITs (15%) + or/matières premières (10%) + monétaire (10%).
- **Auto-portage** — À yield 4%, les dividendes annuels couvrent intégralement les intérêts Lombard.

## À documenter

- [ ] Formulation doctrinale complète de la Double Boucle (origine, paternité Florent Gibert, historique)
- [ ] Démonstration mathématique du facteur géométrique ×5
- [ ] Conditions de déclenchement et de réinjection automatique
- [ ] Politique de rebalancement du portefeuille bourse sous-jacent
- [ ] Gestion du risque margin call (avant délégation Cascade SPV)
- [ ] Articulation explicite avec la 1ʳᵉ Constitution Capital Sociétaire Inaliénable (garantie de non-liquidation du sous-jacent)
- [ ] Schéma graphique de la boucle infinie (référence : graphique « COLHYBRI USA — Double Boucle Infinie » trajectoire 36 mois)
- [ ] [À documenter par Florent Gibert] — date de formalisation initiale et signatures

---

*Stub créé le 13 mai 2026 dans la collection `00-Constitutions-Financieres/`. À upgrader en v1.0 lors de la revue CEO + CFO + Board Advisor M+3.*
