---
title: "Capital Sociétaire Inaliénable"
date: 2026-05-13
type: constitution-financiere
status: stub
author: Florent Gibert
group: ONLYMORE Group
vault_path: "00-Constitutions-Financieres/"
moc: "[[_MOC-Constitutions-Financieres]]"
aliases:
  - Capital-Societaire-Inalienable
tags:
  - onlymore/constitution/finance
  - onlymore/doctrine/bourse
  - onlymore/filiale/colhybri
  - onlymore/filiale/onlymore-finance
version: 0.1
related:
  - "[[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3]]"
  - "[[2026-05-13-Constitution-Double-Boucle-Infinie]]"
---

# Capital Sociétaire Inaliénable

**1ʳᵉ Constitution Financière ONLYMORE Group.**

Le capital apporté par les sociétaires ne peut jamais être consommé, liquidé, ni redistribué en numéraire. Il reste indéfiniment la propriété collective du groupe. Le capital reste intact à vie ; l'impact se déploie chaque jour via la capacité de crédit générée.

> [!warning] Statut : DRAFT — Document à formaliser
> Ce document est un stub. La rédaction constitutionnelle complète de la 1ʳᵉ Constitution reste à produire, en cohérence avec les deux constitutions suivantes ([[2026-05-13-Constitution-Double-Boucle-Infinie|Double Boucle Infinie]] et [[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3|Cascade Mutualiste SPV]]).

## Référence parent

Voir [[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3|Cascade Mutualiste SPV — 3ᵉ Constitution]], notamment :

- Doctrine fondatrice en exergue (*« Les sociétaires ne donnent pas, ils investissent dans un patrimoine commun inaliénable »*)
- Préambule, tableau des trois constitutions
- Partie III, tableau des couches doctrinales (rôle : *« Garantit que le sous-jacent bourse de chaque SPV n'est jamais liquidé »*)
- Annexe 1, glossaire : *Capital inaliénable*

## Éléments connus (extraits Cascade SPV)

- **Principe** — Le capital ne peut être ni liquidé, ni redistribué en numéraire, ni vendu.
- **Propriété** — Propriété collective indéfinie des sociétaires.
- **Rôle dans la triptyque** — Garantit que le sous-jacent bourse de chaque SPV mensuel n'est jamais liquidé, condition de pérennité de la Double Boucle et de la Cascade SPV.
- **Promesse fondatrice associée** — *« Personne ne consomme le capital commun, tout le monde bénéficie de ses fruits. »*
- **Héritage doctrinal** — 220 ans de mutualisme français (Crédit Mutuel, MAIF, MACIF), modèle Green Bay Packers (community ownership), tradition napolitaine du caffè sospeso, antériorité INPI Soleau Florent Gibert (2008–2011).
- **Référence européenne** — Résolution Parlement Européen P10_TA(2025)0212 du 7 octobre 2025 (552 votes, 86,4%).

## À documenter

- [ ] Formulation juridique précise de l'inaliénabilité (statuts holding mutualiste, France)
- [ ] Mécanique de souscription sociétaire (montant minimum, modalités, traçabilité)
- [ ] Régime fiscal du capital sociétaire (FR, à terme US et autres juridictions)
- [ ] Clause de transmission / succession en cas de décès sociétaire
- [ ] Procédure de retrait sociétaire (interdite ? remboursable à valeur nominale uniquement ?)
- [ ] Articulation avec ONLYMORE FINANCE (rôle de teneur de compte sociétaire)
- [ ] Articulation avec la Résolution Parlement Européen P10_TA(2025)0212
- [ ] [À documenter par Florent Gibert] — Référence INPI Soleau exacte (numéros, dates 2008–2011)
- [ ] [À documenter par Florent Gibert] — Reconnaissance ACPR / Banque de France visée

---

*Stub créé le 13 mai 2026 dans la collection `00-Constitutions-Financieres/`. À upgrader en v1.0 lors de la revue CEO + CFO + Board Advisor M+3.*
