---
title: "Charte du Fonds des Services Suspendus"
date: 2026-05-13
type: charte
status: stub
author: Florent Gibert
group: ONLYMORE Group
vault_path: "00-Constitutions-Financieres/"
moc: "[[_MOC-Constitutions-Financieres]]"
aliases:
  - Charte-Fonds-Services-Suspendus
tags:
  - onlymore/charte
  - onlymore/filiale/colhybri
  - onlymore/doctrine/spv
version: 0.1
related:
  - "[[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3]]"
---

# Charte du Fonds des Services Suspendus

Doctrine d'affectation et de distribution des services suspendus financés par la capacité Lombard de la Cascade Mutualiste SPV. La charte instaure la traçabilité sociétaire-à-bénéficiaire — chaque sociétaire est rattaché à *son* SPV mensuel, et peut savoir précisément combien et où ses contributions ont produit de solidarité concrète. Héritage doctrinal direct du caffè sospeso napolitain.

> [!warning] Statut : DRAFT — Document à formaliser
> Ce document est un stub. La charte complète Fonds Services Suspendus, incluant règles d'éligibilité, de plafond, et de gel temporaire, reste à rédiger formellement.

## Référence parent

Voir [[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3|Cascade Mutualiste SPV — 3ᵉ Constitution]], notamment :

- Partie V, point 7 *« Story-telling sociétaire »*
- Partie VI *« Levier d'impact services suspendus »*
- Partie VII, point 7 *« Gel temporaire en cas de margin call »*
- Annexe 1, glossaire : *Caffè sospeso*

## Éléments connus (extraits Cascade SPV)

- **Origine doctrinale** — Tradition napolitaine du caffè sospeso (payer un café d'avance pour un inconnu dans le besoin).
- **Source de financement** — Capacité Lombard tirée sur les SPV mensuels COLHYBRI (puis CROWNIUM, DOJUKU SHINGI, OMFIN, PLUMAYA).
- **Volume cible à M12** — Services suspendus distribués ~11 M$/mois.
- **Ratio levier d'impact à M12** — ×22 (pour 1$ d'intérêt versé à la banque privée, 22$ de solidarité concrète distribués).
- **Règle d'or à formaliser** *(citée au doc parent)* — *« Pour 1$ d'intérêt versé à la banque privée, 22$ de solidarité concrète sont distribués aux quartiers américains. C'est le meilleur ratio impact/coût jamais atteint par une structure de redistribution mutualiste. »*
- **Story-telling sociétaire** — Narration type *« Madame Dupont, votre adhésion finance aujourd'hui 850 cafés suspendus à Detroit. »*
- **Garde-fou n°7 (Partie VII)** — En cas de margin call, les versements services suspendus du mois sont **gelés** (pas réduits, gelés temporairement). La position bourse passe avant tout car elle garantit la pérennité du dispositif sur 50 ans.
- **Modularité doctrinale (avantage stratégique n°5)** — Affectation territoriale écrite dans les statuts SPV (ex. SPV-2026-05 = Wisconsin).
- **Géographie prioritaire** — Quartiers américains, en particulier Rust Belt (Detroit, Cleveland mentionnés).

## À documenter

- [ ] Définition exhaustive d'un « service suspendu » (catégories : alimentation, hygiène, mobilité, énergie, garde d'enfants, santé, etc.)
- [ ] Critères d'éligibilité des commerçants distributeurs (engagement, exclusivité, plafond)
- [ ] Critères d'éligibilité des bénéficiaires (anonymat, ciblage géographique, fréquence)
- [ ] Procédure de versement et de traçabilité (technologique : Supabase / on-chain ?)
- [ ] Plafond mensuel par bénéficiaire et par foyer
- [ ] Reporting sociétaire individualisé (mécanique du *« Madame Dupont, 850 cafés à Detroit »*)
- [ ] Mécanique exacte de gel temporaire en cas de margin call (durée maximale, conditions de reprise)
- [ ] Articulation avec les commerçants COLHYBRI Standard et Premium Maps+
- [ ] Politique anti-fraude et anti-abus
- [ ] Audit annuel indépendant des fonds distribués
- [ ] [À documenter par Florent Gibert] — Cadre légal US (501(c)(3) ? autre véhicule ?) et FR (fondation reconnue d'utilité publique ? fonds de dotation ?)

---

*Stub créé le 13 mai 2026 dans la collection `00-Constitutions-Financieres/`. À upgrader en v1.0 lors de la revue CEO + CFO + Board Advisor M+3.*
