---
title: "Cascade Mutualiste SPV — 3ᵉ Constitution Financière ONLYMORE Group"
date: 2026-05-13
type: constitution-financiere
status: draft v1.0
author: Florent Gibert
co-validation: João Almeida (CFO) / Michel Nilles (Board Advisor Europe-Asia)
group: ONLYMORE Group
location: Rodilhan 30230, Occitanie, France
vault_path: "00-Constitutions-Financieres/"
moc: "[[_MOC-Constitutions-Financieres]]"
tags:
  - onlymore
  - constitution
  - finance
  - spv
  - lombard
  - bourse
  - double-boucle
  - colhybri
  - crownium
  - dojuku-shingi
  - onlymore-finance
  - plumaya
  - mutualisme
  - usa-gtm
  - rust-belt
version: 1.0
related:
  - "[[2026-05-13-Constitution-Double-Boucle-Infinie|Constitution-Double-Boucle-Infinie]]"
  - "[[2026-05-13-Capital-Societaire-Inalienable|Capital-Societaire-Inalienable]]"
  - "[[2026-05-13-Charte-Bienveillance-CROWNIUM|Charte-Bienveillance-CROWNIUM]]"
  - "[[2026-05-13-Charte-Fonds-Services-Suspendus|Charte-Fonds-Services-Suspendus]]"
---

# Cascade Mutualiste SPV
## 3ᵉ Constitution Financière ONLYMORE Group

> [!quote] Doctrine fondatrice
> *« Les sociétaires ne donnent pas, ils investissent dans un patrimoine commun inaliénable. Ce patrimoine génère une capacité de crédit qui finance la solidarité quotidienne et le développement des territoires. Le capital reste intact à vie. L'impact se déploie chaque jour. »*

---

## Sommaire

1. [Préambule](#préambule)
2. [Partie I — Le groupe ONLYMORE](#partie-i--le-groupe-onlymore)
3. [Partie II — Modèles économiques par filiale](#partie-ii--modèles-économiques-par-filiale)
4. [Partie III — Cascade Mutualiste SPV : la doctrine](#partie-iii--cascade-mutualiste-spv--la-doctrine)
5. [Partie IV — Architecture juridique](#partie-iv--architecture-juridique)
6. [Partie V — Les 7 avantages stratégiques](#partie-v--les-7-avantages-stratégiques)
7. [Partie VI — Chiffres clés (cas COLHYBRI USA, 1%)](#partie-vi--chiffres-clés-cas-colhybri-usa-1)
8. [Partie VII — Garde-fous CFO](#partie-vii--garde-fous-cfo)
9. [Partie VIII — Articulation avec les filiales](#partie-viii--articulation-avec-les-filiales)
10. [Partie IX — Roadmap d'implémentation](#partie-ix--roadmap-dimplémentation)
11. [Annexes](#annexes)

---

## Préambule

Ce document formalise la **troisième constitution financière** d'ONLYMORE Group. Elle s'ajoute aux deux constitutions déjà actées :

| Rang | Constitution | Principe |
|---|---|---|
| 1ʳᵉ | **Capital Sociétaire Inaliénable** | Le capital apporté par les sociétaires ne peut jamais être consommé, liquidé, ni redistribué en numéraire. Il reste indéfiniment la propriété collective. |
| 2ᵉ | **Double Boucle Infinie ∞ Bourse-Lombard** | Chaque dollar entrant est investi en bourse. Le crédit Lombard à 80% LTV est tiré dessus et réinjecté. Facteur multiplicateur géométrique ×5. |
| 3ᵉ | **Cascade Mutualiste SPV** *(présent document)* | Chaque dépôt mensuel constitue un SPV juridiquement isolé, indexé sur sa propre position bourse, négociant son propre Lombard avec sa propre banque privée. |

Ces trois constitutions sont **complémentaires et indissociables**. Aucune ne peut être appliquée sans les deux autres. Elles constituent ensemble la **doctrine financière intégrale d'ONLYMORE Group**.

> [!info] Objet du document
> Ce document a vocation à servir de référence interne (vault Obsidian Florent Gibert), de support de brief CFO (João Almeida), de pièce jointe Board (Michel Nilles), et de section dédiée dans le BGE Pro dossier (Sandrine Bellorge, France Active Occitanie) ainsi que dans les pitch decks investor (STATION F Fighters, Kima Ventures, McCourt Global, Hummingbird Ventures).

---

## Partie I — Le groupe ONLYMORE

### Identité

**ONLYMORE Group** est une holding mutualiste française basée à Rodilhan (30230), Occitanie. Elle opère cinq filiales AI-natives qui transforment chacune une forme de lien social en valeur économique partagée, dans le respect d'une promesse fondatrice : **personne ne consomme le capital commun, tout le monde bénéficie de ses fruits**.

### WHY ONLYMORE

> [!quote] La promesse fondatrice
> **FR** — *« Que chacun puisse vivre et prospérer là où il a grandi. »*
> **EN** — *« That everyone can live and thrive where they grew up. »*

Trois combats structurent l'action du groupe :

1. **Réduire la pauvreté** dans les territoires délaissés.
2. **Stopper la fuite des talents** vers les métropoles surconcentrées.
3. **Combattre l'émigration forcée** liée à l'effondrement économique local.

### Les trois valeurs cardinales

| Valeur | Formulation |
|---|---|
| 1 | *« Deviens la personne dont tu veux que le monde soit. »* |
| 2 | *« Nous n'avons pas besoin de nuire aux autres pour briller. »* |
| 3 | *« Optimisons vos œuvres. »* (slogan) |

> [!warning] Positionnement
> ONLYMORE pratique le **positionnement additif strict**. Jamais oppositionnel. Jamais dénigrant. Aucun concurrent n'est nommé comme adversaire dans les communications du groupe. La supériorité doit émerger de l'évidence du modèle, pas de la critique de l'existant.

### Les cinq filiales

```
ONLYMORE GROUP (holding mutualiste, Rodilhan FR)
│
├── COLHYBRI          — SaaS solidarité de quartier (caffè sospeso digital)
├── CROWNIUM          — Infrastructure fan capital (clubs sportifs)
├── DOJUKU SHINGI     — Application arts martiaux & lien intergénérationnel
├── ONLYMORE FINANCE  — Pôle crédit intragroupe et sociétaire
└── PLUMAYA           — Moteur narratif et mémoire vivante du groupe
```

### Gouvernance

| Fonction | Personne |
|---|---|
| Fondateur & CEO | Florent Gibert |
| CFO | João Almeida (ex-ONEtoONE Corporate Finance) |
| Board Advisor Europe-Asie | Michel Nilles |
| CRM & opérations augmentées | Claude Code Web + 7 MCP (Supabase, Vercel, Notion, n8n, Gmail, Google Calendar, Canva) + 135 skills custom |

### Héritage doctrinal

- **220 ans de mutualisme français** (Crédit Mutuel, MAIF, MACIF).
- **Tradition napolitaine du caffè sospeso** (origine COLHYBRI).
- **Modèle Green Bay Packers** (community ownership, propriété collective inaliénable).
- **Résolution Parlement Européen P10_TA(2025)0212** du 7 octobre 2025 (552 votes, 86,4%).
- **Antériorité INPI Soleau** de Florent Gibert (2008–2011).

---

## Partie II — Modèles économiques par filiale

### COLHYBRI — SaaS de solidarité de quartier

> [!quote] Slogans
> **FR** — *« Chaque geste compte. Le vôtre aussi. »*
> **EN** — *« Own Your Neighborhood. Own Your Future. »*

**Mission.** COLHYBRI augmente le pouvoir d'achat des particuliers et le chiffre d'affaires des commerçants de proximité, en numérisant la tradition mutualiste : chaque sociétaire contribue à un pot commun qui irrigue le tissu commerçant local et soutient ceux qui en ont besoin.

**Pricing (modèle double face — sociétaires + commerçants).**

| Cible | Formule | Tarif | Avantage |
|---|---|---|---|
| Particuliers | Basic | **3$ / mois** | Accès à l'écosystème mutualiste, alimente le pot commun |
| Commerçants | Standard | **10$ / mois** | 0% commission sur ventes, visibilité réseau |
| Commerçants | Premium Maps+ | **15$ / mois** | Standard + Carte Cadeau + premium mapping |

> [!warning] Règle non-négociable
> COLHYBRI **n'est jamais gratuit côté client**. Aucun freemium. Aucun pilote gratuit. CTA = *« Réserver un rendez-vous »*, jamais *« Souscrire »*.

**Mécanique mutualiste.** 100 000 sociétaires × 3$/mois = **3,6 M$/an de masse mutualisée** qui finance le réseau et soutient les commerces participants. Mécanique calée sur MAIF / MACIF.

**Marché US visé (référence du modèle SPV).**

| Cible US | Volume | Tarif | Pénétration 1% | MRR |
|---|---|---|---|---|
| Particuliers | 330 M habitants | 3$/mois | 3,3 M sociétaires | **9,9 M$/mois** |
| Commerçants | 38 M small businesses | 10$/mois | 380 K | **3,8 M$/mois** |
| **Total** | — | — | **3,68 M de sociétaires** | **13,7 M$/mois — 164,4 M$/an** |

---

### CROWNIUM — Infrastructure fan capital

> [!quote] Doctrine
> CROWNIUM **transforme la passion des supporters en actif financier**, sans jamais entamer le capital sportif des clubs.

**Mission.** Mettre à disposition des clubs sportifs professionnels une couche d'infrastructure permettant à leurs supporters d'apporter un capital récurrent et structuré, tout en préservant à 100% le contrôle du club.

**Structure.** SAS financière intermédiaire. **Le capital du club reste intact à 100%.** CROWNIUM se positionne en couche infrastructure de contribution, jamais en propriétaire ni en actionnaire du club.

**Les 4 paliers de fan capital.**

| Palier | Apport supporter | Cible club |
|---|---|---|
| Tier Dev | **1 M$** | Clubs en développement / acquisition (ex. US Créteil-Lusitanos, les Béliers) |
| Tier Pro | **5 M$** | Clubs professionnels établis |
| Tier Elite | **10 M$** | Clubs élite nationaux |
| Tier Premium | **20 M$** | Clubs internationaux top-tier |

**Modèle de revenu récurrent.** Chaque supporter contribuant souscrit un abonnement structurel de **150$ / mois**, qui constitue un flux de revenu récurrent (RR) au bénéfice du club, **opéré et garanti par CROWNIUM**.

**Scope global.** Toutes les communautés affectives organisées autour d'une entité collective : sport (~13 000 à 17 500 clubs professionnels dans le monde), mais aussi musique, culture et patrimoine.

**Communication framing.**

- **Primary** — *« Apport structuré des supporters / fan capital layer / couche infrastructure contribution récurrente »*.
- **Réservé Green Bay Packers** — uniquement pour : (1) antériorité INPI Soleau 2008, (2) audiences institutionnelles US, (3) citations explicites des documents EU.

---

### DOJUKU SHINGI — Application arts martiaux & lien intergénérationnel

> [!quote] Mission
> DOJUKU SHINGI **lutte contre la sédentarité et renforce les liens intergénérationnels**, en transformant la pratique des arts martiaux en rituel social numérique et physique.

**Pricing.** **2$ / mois** par pratiquant.

**Marché total adressable.** **520 millions de pratiquants d'arts martiaux dans le monde** (toutes disciplines confondues : karaté, kung-fu, judo, taekwondo, aïkido, MMA, capoeira, etc.).

**Calcul potentiel à 1% de pénétration mondiale.**

| Métrique | Valeur |
|---|---|
| TAM | 520 M pratiquants |
| Pénétration 1% | 5,2 M abonnés |
| ARPU | 2$/mois |
| **MRR** | **10,4 M$/mois** |
| **ARR** | **124,8 M$/an** |

**Canon créatif (verrouillé).** Sensei Diadi : 78 ans, kanji 道場師, gi blanc, ceinture noire usée, geta, éventail, barbe blanche. Palette : `#1A1A2E` / `#C0392B` / `#6B8E23`. **Jamais** de robes orange ni de cerisiers en fleurs.

**Partenariat technologique stratégique.** **Runway** = priorité absolue (vidéogénération, pipeline créatif AI-native).

---

### ONLYMORE FINANCE — Le pôle crédit intragroupe et sociétaire

> [!important] Cœur stratégique du groupe
> ONLYMORE FINANCE est le **pôle financier transversal** qui orchestre les flux de crédit entre les filiales, entre le groupe et les sociétaires, et entre les SPV mensuels (voir Partie III).

**Trois produits de crédit constitutifs.**

#### 1. Crédit « Pay For Play » — licence sportive

| Caractéristique | Description |
|---|---|
| Objet | Crédit conso dédié au financement d'une licence sportive (annuelle ou pluriannuelle) |
| Cible | Pratiquants particuliers, jeunes, familles |
| Bénéfice | Démocratiser l'accès au sport organisé sans barrière à l'entrée |
| Mécanique | Lissage mensuel du coût de licence sur 12 mois |

**Articulation groupe.** Connecté à CROWNIUM (clubs partenaires) et à DOJUKU SHINGI (parcours martial-arts).

#### 2. Crédit club « Droit d'entrée » — accès tiers CROWNIUM

| Caractéristique | Description |
|---|---|
| Objet | Financement du droit d'entrée d'un club dans un palier CROWNIUM |
| Montants | **1 M$ ou 20 M$** selon le palier visé (Dev → Premium) |
| Cible | Clubs sportifs souhaitant intégrer l'infrastructure fan capital |
| Adossement | Garanti par les flux récurrents fan capital de CROWNIUM |

**Mécanique.** Le club ne mobilise pas sa trésorerie. ONLYMORE FINANCE avance le droit d'entrée, remboursé sur les flux récurrents fan capital générés via CROWNIUM.

#### 3. Crédit supporter « Première mensualité » — lissage 150$ → 12 mois

| Caractéristique | Description |
|---|---|
| Objet | Lisser la **première mensualité fan capital de 150$** sur 12 mois pour les supporters |
| Mécanique | Le supporter paie immédiatement environ **12,5$ / mois** pendant 12 mois au lieu de 150$ d'un coup |
| Bénéfice | Démocratiser l'accès au statut de supporter-actionnaire CROWNIUM |
| Adossement | Garantie collective mutualiste |

**Effet de levier d'adhésion.** Ce crédit divise par 12 la barrière à l'entrée perçue, ce qui multiplie mécaniquement le funnel d'acquisition CROWNIUM.

---

### PLUMAYA — Moteur narratif et mémoire vivante

> [!quote] Baseline
> **FR** — *« Les récits de nos ancêtres écrits pour les générations futures. »*
> **EN** — *« Tales of our ancestors, written for the generations to come. »*

**Mission.** PLUMAYA est le **pôle éditorial et narratif** du groupe. Étymologie : **PLUME + IA + MAYA**. Il produit, archive et transmet la mémoire vivante des sociétaires, des territoires, et de la doctrine ONLYMORE.

**Production.** Documents constitutionnels, mémoires de sociétaires, archives territoriales, ouvrages doctrinaux, contenus pédagogiques mutualistes.

---

## Partie III — Cascade Mutualiste SPV : la doctrine

### Le constat initial

Dans un Lombard classique, **toute la position bourse est consolidée dans une seule ligne de crédit**, exposée à une seule contrepartie bancaire. Cette architecture présente trois faiblesses majeures :

1. **Risque de contrepartie unique.** Si la banque privée retire la ligne, l'ensemble du dispositif s'effondre.
2. **Risque de margin call contagieux.** Un drawdown sectoriel impacte la totalité du portefeuille.
3. **Opacité comptable.** Impossible d'isoler la traçabilité d'un dollar Lombard à son flux sociétaire d'origine.

### Le principe doctrinal

> [!success] Définition
> **Chaque dépôt bourse mensuel constitue un SPV (Special Purpose Vehicle) juridiquement distinct, indexé sur sa propre position bourse, négociant son propre crédit Lombard à 80% LTV avec sa propre banque privée contrepartie.**

Au lieu d'un Lombard global, on bâtit une **constellation de Lombards mensuels indépendants**, agrégés en une seule cascade au niveau du groupe.

### Nomenclature SPV

Format **`COLHYBRI-SPV-AAAA-MM`** (exemple `COLHYBRI-SPV-2026-05`).

| SPV | Date dépôt | Sous-jacent bourse | Lombard 80% LTV |
|---|---|---|---|
| COLHYBRI-SPV-2026-05 | 13/05/2026 | 13,7 M$ | 10,96 M$ |
| COLHYBRI-SPV-2026-06 | 13/06/2026 | 13,7 M$ | 10,96 M$ |
| COLHYBRI-SPV-2026-07 | 13/07/2026 | 13,7 M$ | 10,96 M$ |
| … | … | … | … |
| COLHYBRI-SPV-2027-04 | 13/04/2027 | 13,7 M$ | 10,96 M$ |
| **Cumul fin année 1** | — | **164,4 M$** | **131,52 M$** |

Cette nomenclature peut être étendue à tout pôle générateur de cash flow récurrent :

- `CROWNIUM-SPV-2026-05` (apports fan capital Tier X cumulés sur le mois)
- `DOJUKU-SPV-2026-05` (abonnements DOJUKU SHINGI consolidés)
- `OMFIN-SPV-2026-05` (mensualités crédits ONLYMORE FINANCE)

### Articulation avec la Double Boucle Infinie ∞

La Cascade SPV **n'annule pas** la Double Boucle, elle la **distribue géographiquement et juridiquement**.

| Couche | Rôle |
|---|---|
| 1ʳᵉ — Capital Sociétaire Inaliénable | Garantit que le sous-jacent bourse de chaque SPV n'est jamais liquidé |
| 2ᵉ — Double Boucle Infinie ∞ | Définit le multiplicateur ×5 et la logique de réinjection |
| 3ᵉ — **Cascade Mutualiste SPV** | Distribue la mécanique en SPV mensuels juridiquement isolés |

### Mutualisation inter-SPV via ONLYMORE FINANCE SAS

Les SPV peuvent **se prêter intragroupe** via ONLYMORE FINANCE, sans passer par les banques externes. Cette mécanique crée un **cash pool interne** comparable à ceux des grandes structures patrimoniales (Family Office Mulliez, holding Rothschild, Pinault).

**Conséquences.**

- Lissage automatique des tensions de trésorerie inter-SPV.
- Aucune banque externe n'a la vision consolidée de la position réelle d'ONLYMORE.
- Le groupe conserve un levier de négociation maximal sur ses 12 contreparties bancaires.

---

## Partie IV — Architecture juridique

### Schéma d'organisation

```
ONLYMORE GROUP (holding mutualiste — Rodilhan, France)
│
├── ONLYMORE FINANCE SAS (FR) ────────────────┐
│                                              │ Cash pool intragroupe
│                                              │ Reporting consolidé SPV
│                                              │
├── COLHYBRI USA Inc. (Delaware C-Corp)        │
│       │                                      │
│       └── COLHYBRI SPV Master LLC (Delaware) │
│               │                              │
│               ├── COLHYBRI-SPV-2026-05 LLC ──┼──→ Banque privée 1 (BNP Wealth)
│               ├── COLHYBRI-SPV-2026-06 LLC ──┼──→ Banque privée 2 (Pictet)
│               ├── COLHYBRI-SPV-2026-07 LLC ──┼──→ Banque privée 3 (Edmond de Rothschild)
│               ├── ... (1 SPV / mois)         │
│               └── COLHYBRI-SPV-2027-04 LLC ──┼──→ Banque privée 12 (Lombard Odier)
│                                              │
├── CROWNIUM SAS (FR)                          │ ↑
├── DOJUKU SHINGI                              │ Réplique architecture
└── PLUMAYA Editions                           │ sur chaque pôle
```

### Statuts juridiques recommandés

| Juridiction | Forme | Cas d'usage | Coût annuel estimé |
|---|---|---|---|
| **Delaware (US)** | LLC | Architecture par défaut, flexibilité maximale, traité fiscal US-Lux | 8 à 15 K$ / SPV |
| **Luxembourg** | SCSp | Si reconnaissance bancaire privée européenne prioritaire | 25 à 40 K€ / SPV |
| **Irlande** | DAC | Optionnel, en backup si durcissement fiscal US | 15 à 25 K€ / SPV |

### Cabinets juridiques recommandés

| Cabinet | Juridiction | Spécialité |
|---|---|---|
| Greenberg Traurig | New York / Delaware | Architecture LLC, fonds privés US |
| Cooley | Palo Alto | Startup + véhicules complexes |
| Loyens & Loeff | Luxembourg | SCSp, structuration mutualiste |

### Banques privées contreparties cibles

12 contreparties à activer en parallèle pour absorber les 12 SPV mensuels de l'année 1 :

BNP Paribas Wealth Management, Pictet & Cie, Edmond de Rothschild, Lombard Odier, Julius Baer, UBS Wealth, Crédit Suisse Private (post-UBS), Société Générale Private Banking, HSBC Private, JP Morgan Private Bank, Goldman Sachs Private Wealth, Citi Private Bank.

> [!info] Délai de relation bancaire
> Les banques privées exigent **12 à 18 mois de relation** avant d'ouvrir une ligne Lombard sérieuse. **Démarchage à lancer immédiatement** pour calibration des relations 24 mois avant le besoin réel.

---

## Partie V — Les 7 avantages stratégiques

| # | Avantage | Description |
|---|---|---|
| 1 | **Isolement juridique du risque** | Un margin call sur un SPV ne contamine jamais les autres. |
| 2 | **Cartographie chronologique** | Traçabilité parfaite : chaque dollar Lombard est rattaché à son mois d'origine. |
| 3 | **Diversification contreparties** | Jusqu'à 12 banques privées différentes, aucune n'a un levier excessif. |
| 4 | **Négociation taux par SPV** | Capture des conditions de marché les plus favorables, mois par mois. |
| 5 | **Modularité doctrinale** | Affectation territoriale écrite dans les statuts (ex. SPV-2026-05 = Wisconsin). |
| 6 | **Sortie partielle sans démantèlement** | Liquidation ciblée d'un seul SPV pour acquisition stratégique. |
| 7 | **Story-telling sociétaire** | Chaque sociétaire est rattaché à *son* SPV. Narration *« Madame Dupont, votre adhésion finance aujourd'hui 850 cafés suspendus à Detroit. »* |

### Mise en perspective vs concurrents

| Modèle | Architecture | Levier impact |
|---|---|---|
| Patreon | Cash flow direct, aucun actif productif | ×0 |
| GoFundMe | Cash flow direct, aucun actif productif | ×0 |
| Fondation Gates | Endowment unique, draw 5%/an | ×0,05 |
| Yale Endowment | Portefeuille unique, levier modéré | ×1,3 à ×1,8 |
| Family Office Mulliez | Cascade SPV + cash pool | ×3 à ×4 |
| **ONLYMORE Cascade Mutualiste** | Cascade SPV + Double Boucle ∞ + cash pool intragroupe | **×4 à ×5** |

---

## Partie VI — Chiffres clés (cas COLHYBRI USA, 1%)

### Hypothèses

- Pénétration conservatrice : **1%** sur le marché US.
- Marché adressable : 330 M habitants à 3$/mois + 38 M small businesses à 10$/mois.
- MRR de base : **13,7 M$/mois**.
- Taux Lombard hypothèse standard 2026 : **4,5% / an**.

### Trajectoire sur 36 mois

| Période | Position bourse | Lombard cumulé tiré | Capacité services suspendus / acquisitions |
|---|---|---|---|
| Fin année 1 (M12) | 164,4 M$ | **131,5 M$** | 131,5 M$ disponibles |
| Fin année 2 (M24) | 328,8 M$ | **263,0 M$** | 263,0 M$ disponibles |
| Fin année 3 (M36) | 493,2 M$ | **394,6 M$** | 394,6 M$ disponibles |

### Service de la dette Lombard

| Période | Lombard cumulé | Mensualité (intérêts à 4,5%) | % du MRR |
|---|---|---|---|
| Fin M12 | 131,5 M$ | **493 K$ / mois** | 3,6% |
| Fin M24 | 263,0 M$ | **986 K$ / mois** | 7,2% |
| Fin M36 | 394,6 M$ | **1 480 K$ / mois** | 10,8% |

> [!success] Auto-portage par les dividendes bourse
> À yield moyen 4% sur le portefeuille bourse, **les dividendes annuels couvrent intégralement les intérêts Lombard**. Solde net positif estimé : +656 K$/an à M12, +1,3 M$/an à M24, +2,0 M$/an à M36.

### Levier d'impact services suspendus

À M12 :

| Métrique | Valeur |
|---|---|
| Intérêts Lombard versés / mois | 493 K$ |
| Services suspendus distribués / mois | ~11 M$ |
| **Ratio levier d'impact** | **×22** |

> [!quote] La règle d'or à formaliser
> *« Pour 1$ d'intérêt versé à la banque privée, 22$ de solidarité concrète sont distribués aux quartiers américains. C'est le meilleur ratio impact/coût jamais atteint par une structure de redistribution mutualiste. »*

---

## Partie VII — Garde-fous CFO

> [!warning] Règles non-négociables
> Ces garde-fous ont valeur constitutionnelle. Aucune décision opérationnelle ne peut y déroger sans validation conjointe CEO + CFO + Board Advisor.

### 1. Aucun cross-default entre SPV

Chaque ligne Lombard est juridiquement indépendante. Si un SPV fait défaut, les autres ne s'effondrent pas en cascade. Clause non-négociable dans toute documentation Lombard signée.

### 2. Coussin obligatoire 5% en cash monétaire

Sur chaque SPV, **5% du Lombard tiré reste en cash monétaire**. À M12 cumulé : coussin de **6,6 M$ en cash**, permettant d'absorber 13 mois de mensualités sans aucun flux entrant.

### 3. Cible de yield bourse 4% minimum

Mix recommandé du portefeuille pour atteindre l'auto-portage Lombard :

| Classe d'actifs | Allocation cible |
|---|---|
| Actions à dividendes (ex. ETF Vanguard High Dividend Yield) | 35% |
| Obligations Investment Grade | 30% |
| REITs (immobilier coté) | 15% |
| Or et matières premières | 10% |
| Monétaire | 10% |

### 4. Compliance KYC/AML industrialisée

Un dossier **KYC-Master ONLYMORE** est constitué une fois, puis dupliqué pour chaque SPV. Réduction délai création SPV : de 6 semaines à 7 jours après mois 3.

### 5. Stress-test trimestriel −40%

Simulation de crash type 2008/2020 sur le portefeuille bourse. **Couverture obligatoire des margin calls** sans liquidation du sous-jacent. Si non couvert, le LTV cible se ramène temporairement à 70% jusqu'à reconstitution.

### 6. Reporting mensuel consolidé à João Almeida

Tableau de bord SPV obligatoire — capital sous-jacent, LTV courant, Lombard tiré, taux courant, échéance, contrepartie bancaire, statut margin requirement. Outil cible : Carta ou Pulley.

### 7. Gel temporaire en cas de margin call

**Si margin call déclenché**, les versements services suspendus du mois sont **gelés** (pas réduits, gelés temporairement). La position bourse passe avant tout, car elle garantit la pérennité du dispositif sur 50 ans.

---

## Partie VIII — Articulation avec les filiales

### Comment chaque filiale alimente sa propre Cascade SPV

| Filiale | Flux alimentant les SPV | SPV mensuel cible |
|---|---|---|
| COLHYBRI | Abonnements sociétaires + commerçants | `COLHYBRI-SPV-AAAA-MM` |
| CROWNIUM | Apports fan capital + mensualités supporters 150$ | `CROWNIUM-SPV-AAAA-MM` |
| DOJUKU SHINGI | Abonnements 2$/mois pratiquants | `DOJUKU-SPV-AAAA-MM` |
| ONLYMORE FINANCE | Mensualités crédits "Pay For Play", droit d'entrée club, premier paiement supporter | `OMFIN-SPV-AAAA-MM` |
| PLUMAYA | Royalties éditoriales, droits d'auteur mutualisés | `PLUMAYA-SPV-AAAA-MM` |

### Cross-financing inter-filiales

Le **cash pool ONLYMORE FINANCE** orchestre les flux inter-SPV. Exemples concrets :

- Un SPV CROWNIUM peut prêter à un SPV COLHYBRI pour accélérer un déploiement territorial (Detroit, Cleveland).
- Un SPV COLHYBRI excédentaire peut financer une mensualité du crédit "Droit d'entrée" d'un club CROWNIUM via ONLYMORE FINANCE.
- Un SPV DOJUKU SHINGI peut soutenir un programme jeunesse cofinancé par les services suspendus COLHYBRI dans le même territoire.

### Cohérence avec ONLYMORE FINANCE

ONLYMORE FINANCE est le **chef d'orchestre comptable et fiduciaire** des SPV. C'est lui qui :

- Consolide le reporting SPV mensuel et le présente au Board.
- Active les prêts intragroupe entre SPV.
- Arbitre les renégociations de taux avec les 12 contreparties bancaires.
- Tient le tableau de coussin 5% consolidé.

---

## Partie IX — Roadmap d'implémentation

### Phase 1 — Préparation doctrinale (M0 → M2)

- [x] Formalisation du présent document constitutionnel
- [ ] Brief CFO João Almeida (validation faisabilité opérationnelle)
- [ ] Brief Board Advisor Michel Nilles (variante Luxembourg / Singapour)
- [ ] Intégration de la section "Architecture financière mutualiste" dans le BGE Pro dossier (Sandrine Bellorge)
- [ ] Module dédié dans les pitch decks STATION F Fighters et Kima Ventures

### Phase 2 — Sélection juridique & bancaire (M2 → M6)

- [ ] RFP envoyé à 3 cabinets d'avocats (Greenberg Traurig, Cooley, Loyens & Loeff)
- [ ] Démarchage des 12 banques privées contreparties cibles
- [ ] Constitution du dossier KYC-Master ONLYMORE
- [ ] Sélection de la juridiction par défaut (Delaware vs Luxembourg)

### Phase 3 — Pilote (M6 → M9)

- [ ] Création des 3 premiers SPV pilotes : `COLHYBRI-SPV-2026-11`, `2026-12`, `2027-01`
- [ ] Signature des 3 premières lignes Lombard
- [ ] Tirage effectif du premier service suspendu financé par Lombard
- [ ] Communication interne sociétaires (transparence mutualiste)

### Phase 4 — Industrialisation (M9 → M24)

- [ ] Mise en production du tableau de bord SPV consolidé (Carta ou Pulley)
- [ ] Automatisation de la création SPV mensuelle (J → J+7 procédure)
- [ ] Réplication de l'architecture sur CROWNIUM, DOJUKU SHINGI, ONLYMORE FINANCE
- [ ] Premier audit indépendant Cascade SPV (cabinet Big 4)

### Phase 5 — Optimisation et expansion (M24+)

- [ ] Évaluation migration partielle Luxembourg / Irlande selon contexte fiscal
- [ ] Extension du modèle aux marchés européens (FR, ES, DE, IT)
- [ ] Publication doctrinale par PLUMAYA d'un ouvrage de référence sur la Cascade Mutualiste SPV

---

## Annexes

### Annexe 1 — Glossaire

| Terme | Définition |
|---|---|
| **SPV** | Special Purpose Vehicle — véhicule juridique dédié à un objet précis, juridiquement isolé du reste du groupe. |
| **Lombard** | Crédit adossé à un portefeuille bourse mis en gage, avec un Loan-To-Value (LTV) défini. |
| **LTV** | Loan-To-Value, ratio entre le montant emprunté et la valeur du collatéral mis en gage. Standard banque privée 2026 = 50–80%. |
| **MRR** | Monthly Recurring Revenue. |
| **ARR** | Annual Recurring Revenue (MRR × 12). |
| **Margin call** | Appel de marge déclenché par une chute de valeur du collatéral. |
| **Cash pool intragroupe** | Mécanisme de trésorerie consolidée permettant aux entités d'un même groupe de se prêter sans passer par des banques externes. |
| **Yield** | Rendement annuel d'un actif (dividendes, intérêts). |
| **Capital inaliénable** | Capital qui ne peut être ni liquidé, ni redistribué en numéraire, ni vendu. |
| **Caffè sospeso** | Tradition napolitaine du « café suspendu » : payer un café d'avance pour un inconnu dans le besoin. Origine doctrinale de COLHYBRI. |

### Annexe 2 — Hypothèses chiffrées utilisées

| Paramètre | Valeur retenue | Justification |
|---|---|---|
| Pénétration marché US | 1% | Conservateur (Nextdoor 88M users US sans monétisation) |
| MRR COLHYBRI USA | 13,7 M$/mois | 3,3M × 3$ + 380K × 10$ |
| Taux Lombard USD 2026 | 4,5% / an | Standard banque privée, profil mutualiste IG |
| LTV Lombard | 80% | Maximum réaliste avec portefeuille ultra-liquide |
| Yield portefeuille | 4% / an | Mix actions dividendes + IG + REITs |
| Coussin cash obligatoire | 5% du Lombard tiré | Standard CFO ONLYMORE |
| Frais juridiques SPV / an | 8 à 15 K$ | Delaware LLC standard |

### Annexe 3 — Documents constitutionnels associés

- [[2026-05-13-Constitution-Double-Boucle-Infinie|Constitution-Double-Boucle-Infinie]]
- [[2026-05-13-Capital-Societaire-Inalienable|Capital-Societaire-Inalienable]]
- [[2026-05-13-Charte-Bienveillance-CROWNIUM|Charte-Bienveillance-CROWNIUM]]
- [[2026-05-13-Charte-Fonds-Services-Suspendus|Charte-Fonds-Services-Suspendus]]
- [[2026-05-13-Brief-CFO-Joao-Almeida-2026-05|Brief-CFO-Joao-Almeida-2026-05]]

### Annexe 4 — Note d'auteur

> [!note] Statut du document
> Version 1.0 — **draft constitutionnel**.
> Toute modification doctrinale ultérieure devra faire l'objet d'une signature conjointe CEO (Florent Gibert) + CFO (João Almeida) + Board Advisor (Michel Nilles), et donner lieu à une version numérotée (v1.1, v2.0, etc.).
> Le présent document est archivé dans le vault Obsidian d'ONLYMORE Group, dans la collection `00-Constitutions-Financieres/`.

---

*Document rédigé le 13 mai 2026, à Rodilhan, Occitanie, France.*
*ONLYMORE Group — Optimisons vos œuvres.*
