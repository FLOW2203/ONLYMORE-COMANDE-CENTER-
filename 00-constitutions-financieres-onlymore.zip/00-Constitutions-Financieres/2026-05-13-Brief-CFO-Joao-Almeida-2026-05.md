---
title: "Brief CFO João Almeida — Cascade Mutualiste SPV (mai 2026)"
date: 2026-05-13
type: brief-cfo
status: stub enrichi
author: Florent Gibert
group: ONLYMORE Group
vault_path: "00-Constitutions-Financieres/"
moc: "[[_MOC-Constitutions-Financieres]]"
aliases:
  - Brief-CFO-Joao-Almeida-2026-05
tags:
  - onlymore/brief/cfo
  - onlymore/constitution/finance
  - onlymore/doctrine/spv
  - onlymore/doctrine/lombard
  - onlymore/filiale/onlymore-finance
  - onlymore/filiale/colhybri
version: 0.1
related:
  - "[[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3]]"
---

# Brief CFO João Almeida — Cascade Mutualiste SPV

**Destinataire :** João Almeida, CFO ONLYMORE Group (ex-ONEtoONE Corporate Finance)
**Émetteur :** Florent Gibert, CEO ONLYMORE Group
**Date :** 13 mai 2026
**Objet :** Présentation de la 3ᵉ Constitution Financière (Cascade Mutualiste SPV) et validation faisabilité opérationnelle.

> [!warning] Règle non-négociable du groupe
> **Toute proposition de contrat, signature ou engagement structurant se fait en présentiel uniquement.** Ce brief vise une réunion de travail (validation technique). Aucune signature ni engagement à distance ne sera soumis lors de cette session.

## Référence parent

Document constitutionnel complet : [[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3|Cascade Mutualiste SPV — 3ᵉ Constitution Financière]].

## Objet de la réunion

Soumettre à validation CFO la 3ᵉ Constitution Financière du groupe et statuer sur trois points-clé techniques avant déploiement Phase 2 (sélection juridique et bancaire, M2 → M6).

## Les 3 points-clé techniques à valider avec João

### 1. Faisabilité Delaware LLC

- Architecture cible : `COLHYBRI USA Inc. (Delaware C-Corp)` → `COLHYBRI SPV Master LLC (Delaware)` → 12 SPV mensuels Delaware LLC année 1.
- Coût annuel estimé : **8 à 15 K$ / SPV**.
- Cabinets pressentis : Greenberg Traurig (NY/Delaware), Cooley (Palo Alto).
- Question à João : retour d'expérience ONEtoONE Corporate Finance sur des structures équivalentes (cascade LLC, SPV multi-contrepartie). Bloqueurs réglementaires US à anticiper ? Articulation traité fiscal US–Lux pour préserver l'option Luxembourg backup ?

### 2. Coût et délai relations bancaires privées

- Cible : 12 contreparties bancaires activées en parallèle pour absorber les 12 SPV mensuels de l'année 1.
- Liste : BNP Paribas Wealth Management, Pictet & Cie, Edmond de Rothschild, Lombard Odier, Julius Baer, UBS Wealth, Crédit Suisse Private (post-UBS), Société Générale Private Banking, HSBC Private, JP Morgan Private Bank, Goldman Sachs Private Wealth, Citi Private Bank.
- Hypothèse opérationnelle doc parent : **12 à 18 mois de relation préalable** exigés avant ouverture ligne Lombard sérieuse — démarchage à lancer immédiatement pour calibration 24 mois avant besoin réel.
- Question à João : confirmer cette hypothèse de délai au regard de son réseau ; chiffrer le coût d'amorçage (déplacements, due diligence, KYC-Master ONLYMORE) ; identifier les 3-4 banques par lesquelles commencer.

### 3. Compatibilité avec retour d'expérience ONEtoONE Corporate Finance

- Question à João : à partir de son expérience ONEtoONE, identifier ce qui doit être ajusté dans la doctrine pour passer le filtre d'un audit indépendant Big 4 (étape Phase 4 du doc parent).
- Sous-questions : la mécanique de cash pool intragroupe via ONLYMORE FINANCE SAS est-elle défendable réglementairement côté FR (ACPR) et US (FinCEN) ? Le coussin de 5% cash monétaire est-il à la bonne hauteur ou faut-il monter à 7-10% ? Le LTV 80% est-il tenable sur le long terme ou faut-il viser une cible plus conservatrice (70-75%) ?

## Chiffres-clé à mémoriser pour la session

| Indicateur | Valeur | Source |
|---|---|---|
| MRR COLHYBRI USA (pénétration 1%) | **13,7 M$/mois** | Partie II du doc parent |
| ARR COLHYBRI USA correspondant | **164,4 M$/an** | Partie II |
| Lombard cumulé fin M12 (80% LTV) | **131,5 M$** | Partie VI |
| Mensualité intérêts Lombard M12 (4,5%) | **493 K$/mois** | Partie VI |
| Ratio levier d'impact M12 | **×22** | Partie VI |
| Services suspendus distribués / mois M12 | ~11 M$ | Partie VI |
| Coussin cash obligatoire | 5% du Lombard tiré (6,6 M$ à M12) | Partie VII §2 |
| Yield portefeuille cible | 4% / an | Partie VII §3 |

## Agenda proposé pour la réunion (45 min, présentiel)

| Plage | Durée | Sujet |
|---|---|---|
| 00:00 → 00:05 | 5 min | Rappel doctrinal — triptyque constitutionnel (Capital Sociétaire / Double Boucle / Cascade SPV) |
| 00:05 → 00:15 | 10 min | Walk-through architecture juridique (Partie IV) et schéma cascade Delaware |
| 00:15 → 00:25 | 10 min | Point-clé 1 : faisabilité Delaware LLC — discussion ouverte |
| 00:25 → 00:32 | 7 min | Point-clé 2 : coût et délai relations bancaires privées — priorisation des 12 contreparties |
| 00:32 → 00:40 | 8 min | Point-clé 3 : compatibilité expérience ONEtoONE — ajustements doctrinaux éventuels |
| 00:40 → 00:45 | 5 min | Prochaines étapes : RFP cabinets juridiques, lancement KYC-Master, planning Phase 2 |

## Output attendu de la session

- Validation (ou liste d'ajustements doctrinaux) sur les 3 points-clé.
- Priorisation des 3 premières banques privées à démarcher.
- Décision provisoire : juridiction par défaut Delaware ou bascule Luxembourg ?
- Date proposée pour la réunion conjointe CEO + CFO + Board Advisor (Michel Nilles) en présentiel.

> [!info] Garde-fou présentiel
> Conformément à la règle groupe, toute décision engageante (signature mandat cabinet, lettre d'intention bancaire, choix juridiction définitif) sera prise en présentiel uniquement, lors d'une session ultérieure dédiée.

---

*Brief préparé par Florent Gibert le 13 mai 2026, à Rodilhan. À compléter par Florent avant envoi à João.*
