---
title: "Charte de Bienveillance CROWNIUM"
date: 2026-05-13
type: charte
status: stub
author: Florent Gibert
group: ONLYMORE Group
vault_path: "00-Constitutions-Financieres/"
moc: "[[_MOC-Constitutions-Financieres]]"
aliases:
  - Charte-Bienveillance-CROWNIUM
tags:
  - onlymore/charte
  - onlymore/filiale/crownium
  - onlymore/doctrine/spv
version: 0.1
related:
  - "[[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3]]"
---

# Charte de Bienveillance CROWNIUM

Cadre éthique encadrant la relation entre CROWNIUM (couche d'infrastructure fan capital), les clubs sportifs partenaires et les supporters contributeurs. La charte fixe la règle fondatrice : préserver à 100% le capital sportif et le contrôle du club, et positionner CROWNIUM strictement en couche d'infrastructure de contribution récurrente, jamais en propriétaire ni en actionnaire.

> [!warning] Statut : DRAFT — Document à formaliser
> Ce document est un stub. La charte complète CROWNIUM, incluant règles de communication, paliers d'apport et engagement supporters, reste à rédiger formellement.

## Référence parent

Voir [[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3|Cascade Mutualiste SPV — 3ᵉ Constitution]], notamment :

- Partie II, sous-section *« CROWNIUM — Infrastructure fan capital »*
- Partie VIII, articulation alimentation `CROWNIUM-SPV-AAAA-MM`

## Éléments connus (extraits Cascade SPV)

- **Doctrine** — CROWNIUM transforme la passion des supporters en actif financier, sans jamais entamer le capital sportif des clubs.
- **Structure juridique** — SAS financière intermédiaire (France).
- **Règle absolue** — Le capital du club reste intact à 100%. CROWNIUM se positionne en couche infrastructure de contribution, jamais propriétaire ni actionnaire.
- **Paliers de fan capital** — Tier Dev (1 M$), Tier Pro (5 M$), Tier Elite (10 M$), Tier Premium (20 M$).
- **Modèle de revenu récurrent** — Abonnement structurel de 150$/mois par supporter contribuant, RR opéré et garanti par CROWNIUM.
- **Scope** — Sport (~13 000 à 17 500 clubs professionnels mondiaux), extension prévue musique, culture, patrimoine.
- **Communication framing primary** — *« Apport structuré des supporters / fan capital layer / couche infrastructure contribution récurrente »*.
- **Communication framing réservé Green Bay Packers** — uniquement pour : antériorité INPI Soleau 2008, audiences institutionnelles US, citations explicites des documents EU.
- **Crédit supporter associé** — Lissage première mensualité 150$ sur 12 mois → 12,5$/mois pendant 12 mois (cf. ONLYMORE FINANCE).
- **Positionnement additif strict** — Jamais oppositionnel, jamais dénigrant, conformément à la doctrine groupe.

## À documenter

- [ ] Engagement formel CROWNIUM vis-à-vis des clubs partenaires (clauses de non-prise de contrôle, non-vote, non-immixtion sportive)
- [ ] Engagement formel CROWNIUM vis-à-vis des supporters (droits, transparence, sortie)
- [ ] Règles de gouvernance interne (qui décide quel club entre dans quel palier)
- [ ] Politique de communication publique (interdictions, validations, escalades)
- [ ] Articulation avec la 1ʳᵉ Constitution Capital Sociétaire Inaliénable
- [ ] Conditions de réversibilité (que se passe-t-il si un club veut sortir de CROWNIUM)
- [ ] Liste exhaustive des clubs cibles initiaux (US Créteil-Lusitanos, les Béliers mentionnés au doc principal)
- [ ] [À documenter par Florent Gibert] — Cadre réglementaire UEFA et fédérations nationales applicables
- [ ] [À documenter par Florent Gibert] — Articulation avec la Résolution Parlement Européen P10_TA(2025)0212

---

*Stub créé le 13 mai 2026 dans la collection `00-Constitutions-Financieres/`. À upgrader en v1.0 lors de la revue CEO + CFO + Board Advisor M+3.*
