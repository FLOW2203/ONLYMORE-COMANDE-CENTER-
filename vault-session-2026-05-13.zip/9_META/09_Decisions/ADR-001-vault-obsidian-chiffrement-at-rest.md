---
title: "ADR-001 — Vault Obsidian : chiffrement at-rest via git-crypt + GPG"
date: 2026-05-13
type: adr
status: Accepted
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/adr
  - onlymore/securite/vault
  - onlymore/securite/git-crypt
related:
  - "[[obsidian-vault-setup]]"
  - "[[secrets-management]]"
  - "[[2026-05-13-Session-Marathon-Vault-Crypto]]"
---

# ADR-001 — Vault Obsidian : chiffrement at-rest via git-crypt + GPG

## Status

**Accepted** — 13/05/2026.

## Context

Le vault Obsidian de Florent Gibert (`C:\ONLYMORE\00_HOLDING\`) contient progressivement les documents constitutionnels du groupe (3 constitutions financières, chartes opérationnelles), les briefs CFO, le CRM stratégique, et la doctrine sensible (positionnement concurrentiel, M&A pipeline, mémos board).

Sans précaution :

- Sync vers GitHub privé = doctrine accessible à tout détenteur du token GitHub (employés futurs, audit, fuite token).
- Sauvegarde cloud (iCloud / OneDrive / Google Drive) = doctrine accessible aux fournisseurs cloud.
- Vol machine physique = doctrine accessible au porteur du disque.

Le niveau de sensibilité justifie un chiffrement **at-rest** avec une clé maîtrisée uniquement par le CEO.

## Decision

Adopter **`git-crypt` + GPG RSA 4096** pour chiffrer at-rest les dossiers sensibles du vault Obsidian.

- **Outil** : `git-crypt` (AGWA, open source, mature, audit-friendly).
- **Algorithme clé** : RSA 4096 (compatible universellement, vs ECC qui pose des problèmes Windows).
- **Granularité** : par dossier, déclaré dans `.gitattributes`. Permet de garder en clair les MOC et README de navigation.
- **Dossiers chiffrés initiaux** :
  - `9_META/00_CONSTITUTIONS/`
  - `9_META/05_CFO_Briefs/`
  - `9_META/06_Doctrine_Sensible/`
  - `6_CRM/`
- **Exceptions readables** : `9_META/**/README.md`, `9_META/**/_INDEX.md`.
- **Empreinte clé maîtresse** : `FC622EB8056509B4BBC4B436E47ADD21CC605948`.
- **Sauvegarde clé** : 2 supports physiques distincts (clé USB chiffrée VeraCrypt + cloud privé chiffré rclone crypt).
- **Repo distant** : `FLOW2203/onlymore-vault` (privé).

## Consequences

### Positives

- **Confidentialité garantie at-rest** : même si un attaquant obtient le token GitHub, le tarball du repo, ou le disque physique, la doctrine reste illisible sans la clé GPG.
- **Sync transparente** : chiffrement/déchiffrement automatique via filtres git (smudge/clean), pas de friction quotidienne.
- **Granularité fine** : les fichiers de navigation restent en clair, le contenu sensible chiffré.
- **Audit-friendly** : `git-crypt` est open source, code lisible, pas de boîte noire.
- **Évolutif** : ajout futur de collaborateurs (João Almeida, Michel Nilles) via `git-crypt add-gpg-user`.

### Négatives

- **Perte de clé = perte définitive** des fichiers chiffrés. Mitigé par backup 2 supports physiques (cf. ADR + [[secrets-management]]).
- **Friction onboarding nouvelle machine** : nécessite import clé GPG + `git-crypt unlock` avant utilisation. Mitigé par runbook [[obsidian-vault-setup]].
- **Diff illisibles côté GitHub** : impossible de review en web UI, doit cloner localement. Acceptable car on est en solo / petit cercle.
- **Plugin Obsidian Git + passphrase GPG** : risque de blocage silencieux auto-commit. Mitigé via TTL `gpg-agent 28800s` (8h).

### Neutres

- Pas d'impact perf perceptible sur un vault <1 GB.
- Compatible avec sync multi-machine via plugin Obsidian Git.

## Alternatives considered

| Alternative | Pourquoi écartée |
|---|---|
| **Repo public + chiffrement filesystem (BitLocker, FileVault)** | Ne protège pas en cas de fuite remote / cloud. |
| **Repo privé sans chiffrement at-rest** | Token GitHub = pivot critique unique. Fuite token = fuite doctrine. |
| **Outils chiffrement vault (Cryptomator, VeraCrypt)** | Pas d'intégration native git, pas de granularité fichier, friction quotidienne. |
| **Notion privé** | Vendor lock-in fort, pas de chiffrement client-side réel, données chez Notion. |
| **Standard Notes / Obsidian Sync (officiel)** | Coût récurrent, dépendance fournisseur, pas de contrôle sur la clé. |
| **`age` au lieu de `git-crypt`** | Pas d'intégration git native, nécessite scripting custom. |
| **ECC au lieu de RSA** | Problèmes compat `git-crypt` Windows constatés. |

## Implémentation

Exécutée le 13/05/2026 — voir runbook [[obsidian-vault-setup]] (10 phases, 15 min).

Commits de référence sur `main` du vault : `c146f51`, `9c107fe`, `5198517`, `4d392c7`, `e791d72`.

## Revue

- **M+3** (mi-août 2026) : audit fonctionnement, ajustement liste dossiers chiffrés.
- **M+12** : revue pratique cryptographique (RSA 4096 toujours pertinent ? émergence post-quantique ?).

---

*ADR-001 v1.0 — décidé et exécuté le 13 mai 2026.*
