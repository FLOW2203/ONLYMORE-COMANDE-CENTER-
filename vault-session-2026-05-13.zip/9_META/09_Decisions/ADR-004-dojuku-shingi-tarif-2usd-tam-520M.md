---
title: "ADR-004 — DOJUKU SHINGI : tarif 2$/mois sur TAM 520 M pratiquants"
date: 2026-05-13
type: adr
status: Accepted
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/adr
  - onlymore/filiale/dojuku-shingi
  - onlymore/pricing
related:
  - "[[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3]]"
  - "[[ADR-002-architecture-cascade-mutualiste-spv]]"
---

# ADR-004 — DOJUKU SHINGI : tarif 2$/mois sur TAM 520 M pratiquants

## Status

**Accepted** — 13/05/2026.

## Context

DOJUKU SHINGI est la filiale ONLYMORE dédiée aux **arts martiaux et au lien intergénérationnel**. Mission : lutter contre la sédentarité et renforcer les liens intergénérationnels, en transformant la pratique des arts martiaux en rituel social numérique et physique.

Le marché total adressable (TAM) mondial : **520 millions de pratiquants d'arts martiaux** (toutes disciplines : karaté, kung-fu, judo, taekwondo, aïkido, MMA, capoeira, etc.).

Question : quel tarif d'abonnement aligne (a) accessibilité massive, (b) MRR suffisant pour alimenter la Cascade SPV, (c) cohérence doctrinale ONLYMORE (mutualisme abordable) ?

## Decision

Adopter un **tarif unique de 2$ / mois par pratiquant**.

### Calcul potentiel à 1% de pénétration

| Métrique | Valeur |
|---|---|
| TAM | 520 M pratiquants |
| Pénétration 1% | 5,2 M abonnés |
| ARPU | 2$/mois |
| **MRR** | **10,4 M$/mois** |
| **ARR** | **124,8 M$/an** |

### Canon créatif verrouillé

- **Sensei Diadi** : 78 ans, kanji 道場師 (dōjō-shi = maître du dojo), gi blanc, ceinture noire usée, geta, éventail, barbe blanche.
- Palette : `#1A1A2E` / `#C0392B` / `#6B8E23`.
- **Interdits absolus** : robes orange, cerisiers en fleurs (clichés japonisants).

### Partenariat technologique stratégique

**Runway** = priorité absolue (vidéogénération AI-native, pipeline créatif pour contenus kata, démonstrations techniques, rituels intergénérationnels).

## Consequences

### Positives

- **Accessibilité massive** : 2$/mois = barrière à l'entrée minimale même sur marchés émergents (Brésil, Afrique du Sud, Asie du Sud-Est).
- **MRR aligné Cascade SPV** : 10,4 M$/mois à 1% de pénétration mondiale, comparable au MRR COLHYBRI USA (13,7 M$).
- **TAM gigantesque** : 520 M pratiquants = un des plus gros TAM du portefeuille ONLYMORE.
- **Cohérence doctrinale** : tarif abordable = pratique populaire = lien intergénérationnel démocratisé.
- **Levier crédit "Pay For Play"** : couplé au crédit licence sportive d'ONLYMORE FINANCE (cf. ADR-005), la friction d'inscription tombe encore.

### Négatives

- **ARPU faible** : 2$/mois = nécessite volume massif pour rentabilité. Pas adapté à un go-to-market local concentré.
- **Marge à protéger** : tarif faible = pas de marge pour acquisition payante coûteuse. Acquisition doit être virale / via partenariats clubs / fédérations.
- **Dépendance Runway** : si tarif Runway augmente, marge unitaire compressée. Mitigé par négociation partenariat stratégique en amont.

### Neutres

- Pas de tier supérieur prévu au MVP : on garde la simplicité 1 tarif = 1 produit. Tiers Premium à évaluer M+12.

## Alternatives considered

| Alternative | Pourquoi écartée |
|---|---|
| **Freemium** | Brise la doctrine ONLYMORE "jamais gratuit côté client" + dilue le signal d'engagement |
| **5$/mois** | Réduit la pénétration prévue sur marchés émergents, perd la mission "lutte contre sédentarité" universelle |
| **1$/mois** | MRR trop bas (5,2 M$/mois à 1%), insuffisant pour alimenter SPV mensuel viable |
| **10$/mois tier unique** | Trop élitiste, contredit la mission lien intergénérationnel populaire |
| **Pay-per-cours** | Friction transactionnelle élevée, MRR imprévisible, non-aligné Cascade SPV |
| **Annual subscription only** | Trop de friction acquisition initiale |
| **B2B clubs (licence club)** | Possible en parallèle, mais ne remplace pas la mécanique sociétaire individuelle |

## Implémentation

- App DOJUKU SHINGI : React Native + backend Supabase + pipeline Runway.
- Onboarding : choix discipline + niveau + Sensei Diadi narrative arc.
- Contenus produits via Runway : démonstrations kata, conseils intergénérationnels, défis hebdomadaires.
- Partenariats fédérations / clubs locaux pour acquisition.
- Couplage avec crédit "Pay For Play" (ONLYMORE FINANCE) pour licences sportives.

## Revue

- **M+6** : retour data MRR + taux churn. Si churn >5%/mois, revisiter onboarding.
- **M+12** : évaluation tier Premium (3-5$/mois) avec contenus exclusifs / coaching IA.
- **M+18** : extension TAM (e-sport ? lien intergénérationnel non-martial ?).

---

*ADR-004 v1.0 — décidé le 13 mai 2026.*
