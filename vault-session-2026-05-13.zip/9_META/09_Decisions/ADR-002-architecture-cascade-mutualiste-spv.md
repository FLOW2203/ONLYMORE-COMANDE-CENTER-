---
title: "ADR-002 — Architecture Cascade Mutualiste SPV (3ᵉ Constitution Financière)"
date: 2026-05-13
type: adr
status: Accepted
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/adr
  - onlymore/doctrine/finance
  - onlymore/doctrine/spv
  - onlymore/doctrine/lombard
related:
  - "[[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3]]"
  - "[[_MOC-Constitutions-Financieres]]"
  - "[[2026-05-13-Brief-CFO-Joao-Almeida-2026-05]]"
---

# ADR-002 — Architecture Cascade Mutualiste SPV (3ᵉ Constitution Financière)

## Status

**Accepted** — 13/05/2026 (draft v1.0, co-validation CFO en cours).

## Context

ONLYMORE Group avait deux constitutions financières actées :

1. **Capital Sociétaire Inaliénable** — le capital sociétaire ne peut être ni consommé, ni liquidé, ni redistribué.
2. **Double Boucle Infinie ∞** — chaque dollar entrant est investi en bourse, le Lombard à 80% LTV est tiré et réinjecté (facteur géométrique ×5).

Dans un Lombard classique, toute la position bourse est consolidée dans une seule ligne, exposée à une seule contrepartie bancaire. Trois faiblesses :

- Risque de contrepartie unique.
- Risque de margin call contagieux.
- Opacité comptable (impossible de tracer un dollar Lombard à son flux sociétaire d'origine).

Avec un MRR cible COLHYBRI USA de 13,7 M$/mois (164,4 M$/an à pénétration 1%) et un Lombard cumulé M12 de 131,5 M$, la concentration sur une seule contrepartie devient un point unique de défaillance systémique.

## Decision

Adopter la **Cascade Mutualiste SPV** comme 3ᵉ Constitution Financière du groupe.

- Chaque dépôt bourse mensuel constitue un **SPV (Special Purpose Vehicle) juridiquement distinct**.
- Chaque SPV est indexé sur sa propre position bourse et négocie son propre Lombard à 80% LTV avec sa propre banque privée contrepartie.
- Nomenclature : `COLHYBRI-SPV-AAAA-MM`, réplicable sur toutes les filiales (`CROWNIUM-SPV-…`, `DOJUKU-SPV-…`, `OMFIN-SPV-…`, `PLUMAYA-SPV-…`).
- Mutualisation inter-SPV via **ONLYMORE FINANCE SAS** (cash pool intragroupe).
- 12 contreparties bancaires privées activées en parallèle pour absorber les 12 SPV de l'année 1.

## Consequences

### Positives

| # | Avantage |
|---|---|
| 1 | Isolement juridique du risque (un margin call sur un SPV ne contamine jamais les autres) |
| 2 | Cartographie chronologique (traçabilité parfaite mois par mois) |
| 3 | Diversification contreparties (jusqu'à 12 banques privées) |
| 4 | Négociation taux par SPV (capture conditions favorables mensuelles) |
| 5 | Modularité doctrinale (affectation territoriale dans les statuts SPV) |
| 6 | Sortie partielle sans démantèlement (liquidation ciblée d'un seul SPV) |
| 7 | Story-telling sociétaire individualisé (Madame Dupont → SPV-2026-05 → 850 cafés à Detroit) |

Ratio levier d'impact M12 : **×22** (pour 1$ d'intérêt versé à la banque privée, 22$ de solidarité distribués).

### Négatives

- **Coût juridique** : 8-15 K$/SPV/an × 12 SPV = 96-180 K$/an coût récurrent juridique Delaware. À comparer aux 656 K$/an de solde net positif M12 → ROI positif.
- **Complexité opérationnelle** : 12 contreparties bancaires à entretenir, dossiers KYC dupliqués (mitigé via KYC-Master ONLYMORE → délai SPV 7 jours après M3).
- **Délai de mise en place bancaire** : 12 à 18 mois de relation préalable par banque → démarchage à lancer immédiatement.

### Neutres

- Compatibilité technique avec la Double Boucle Infinie : la Cascade SPV ne l'annule pas, elle la distribue géographiquement et juridiquement.
- Compatibilité avec Capital Sociétaire Inaliénable : chaque SPV est indexé sur le sous-jacent bourse, lui-même garanti par la 1ʳᵉ Constitution.

## Alternatives considered

| Alternative | Pourquoi écartée |
|---|---|
| **Lombard unique global** | Point de défaillance unique (risque contrepartie + margin call contagieux + opacité) |
| **2 ou 3 SPV par an seulement** | Granularité insuffisante pour traçabilité sociétaire individualisée |
| **SPV par filiale (et non par mois)** | Pas de cartographie chronologique, fragilité concentrée |
| **Architecture Family Office Mulliez (×3-4 levier)** | Excellente mais ne capture pas le facteur Double Boucle ×5 |
| **Endowment unique style Yale (×1,3-1,8)** | Levier insuffisant face à l'objectif solidarité quotidienne |

ONLYMORE Cascade Mutualiste = **×4 à ×5** (Cascade SPV + Double Boucle + cash pool intragroupe).

## Garde-fous CFO (valeur constitutionnelle)

1. Aucun cross-default entre SPV (clause non-négociable).
2. Coussin 5% cash monétaire par SPV (6,6 M$ à M12, 13 mois de mensualités).
3. Yield bourse cible 4% minimum (auto-portage Lombard).
4. KYC/AML industrialisé via KYC-Master ONLYMORE.
5. Stress-test trimestriel −40%.
6. Reporting mensuel consolidé à João Almeida.
7. Gel temporaire services suspendus en cas de margin call.

## Implémentation

- **Phase 1 (M0 → M2)** : préparation doctrinale (CE document, brief CFO).
- **Phase 2 (M2 → M6)** : RFP cabinets (Greenberg Traurig, Cooley, Loyens & Loeff) + démarchage 12 banques.
- **Phase 3 (M6 → M9)** : 3 SPV pilotes (`COLHYBRI-SPV-2026-11`, `2026-12`, `2027-01`).
- **Phase 4 (M9 → M24)** : industrialisation (Carta/Pulley, automatisation, réplication CROWNIUM/DOJUKU/OMFIN).
- **Phase 5 (M24+)** : optimisation et expansion européenne.

## Revue

- **M+3** : retour réunion CFO João Almeida (validation faisabilité Delaware + priorisation banques).
- **M+6** : sélection juridiction par défaut (Delaware vs Luxembourg).
- **M+12** : premier audit indépendant Big 4.

---

*ADR-002 v1.0 — décidé le 13 mai 2026. Voir doc constitutionnel intégral : [[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3]].*
