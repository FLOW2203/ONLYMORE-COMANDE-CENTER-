---
title: "ADR-005 — ONLYMORE FINANCE : 3 produits de crédit constitutifs"
date: 2026-05-13
type: adr
status: Accepted
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/adr
  - onlymore/filiale/onlymore-finance
  - onlymore/credit
  - onlymore/iobsp
related:
  - "[[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3]]"
  - "[[ADR-002-architecture-cascade-mutualiste-spv]]"
  - "[[ADR-003-doctrine-colhybri-double-face-pricing]]"
  - "[[ADR-004-dojuku-shingi-tarif-2usd-tam-520M]]"
---

# ADR-005 — ONLYMORE FINANCE : 3 produits de crédit constitutifs

## Status

**Accepted** — 13/05/2026.

## Context

ONLYMORE FINANCE est le **pôle financier transversal** d'ONLYMORE Group. Il orchestre :

- Les flux de crédit entre les filiales (COLHYBRI, CROWNIUM, DOJUKU SHINGI, PLUMAYA).
- Les flux entre le groupe et les sociétaires (mécanique mutualiste).
- Les flux entre les SPV mensuels de la Cascade Mutualiste SPV (cash pool intragroupe, cf. ADR-002).

Question : quels produits de crédit définir comme **constitutifs** (cœur d'offre, non-négociables, à concevoir en priorité) vs périphériques (innovations futures) ?

## Decision

Définir **3 produits de crédit constitutifs**, en cohérence avec les filiales et la doctrine groupe.

### 1. Crédit « Pay For Play » — licence sportive

| Caractéristique | Description |
|---|---|
| Objet | Crédit conso dédié au financement d'une licence sportive (annuelle ou pluriannuelle) |
| Cible | Pratiquants particuliers, jeunes, familles |
| Bénéfice | Démocratiser l'accès au sport organisé sans barrière à l'entrée |
| Mécanique | Lissage mensuel du coût de licence sur 12 mois |
| Articulation | Connecté à CROWNIUM (clubs partenaires) et DOJUKU SHINGI (parcours martial-arts) |

### 2. Crédit club « Droit d'entrée » — accès tiers CROWNIUM

| Caractéristique | Description |
|---|---|
| Objet | Financement du droit d'entrée d'un club dans un palier CROWNIUM |
| Montants | **1 M$ ou 20 M$** selon palier visé (Tier Dev → Tier Premium) |
| Cible | Clubs sportifs souhaitant intégrer l'infrastructure fan capital |
| Adossement | Garanti par les flux récurrents fan capital de CROWNIUM |
| Mécanique | Le club ne mobilise pas sa trésorerie. ONLYMORE FINANCE avance, remboursé sur flux récurrents fan capital |

### 3. Crédit supporter « Première mensualité » — lissage 150$ → 12 mois

| Caractéristique | Description |
|---|---|
| Objet | Lisser la première mensualité fan capital de 150$ sur 12 mois |
| Mécanique | Le supporter paie ~**12,5$ / mois** pendant 12 mois au lieu de 150$ d'un coup |
| Bénéfice | Démocratiser l'accès au statut de supporter-actionnaire CROWNIUM |
| Adossement | Garantie collective mutualiste |
| Effet de levier | Divise par 12 la barrière à l'entrée perçue → multiplie le funnel d'acquisition CROWNIUM |

## Consequences

### Positives

- **Couverture des 2 marchés simultanément** :
  - Côté demande (joueurs, supporters) : Pay For Play + Première mensualité supporter
  - Côté offre (clubs) : Droit d'entrée CROWNIUM
- **Effet multiplicateur acquisition** : crédit Première mensualité divise par 12 la barrière à l'entrée perçue → multiplication mécanique du funnel CROWNIUM.
- **Liquidité intragroupe** : ONLYMORE FINANCE devient le chef d'orchestre comptable des SPV (cash pool), donnant au groupe un levier maximal vis-à-vis des banques privées externes.
- **Cohérence avec Cascade SPV** : les mensualités collectées alimentent un SPV mensuel `OMFIN-SPV-AAAA-MM` qui contribue à la doctrine groupe.
- **Démocratisation systématique** : aucun des 3 produits n'est élitiste, tous abaissent les barrières d'accès.

### Négatives

- **Risque crédit** : 3 produits = 3 profils de risque distincts à gérer (particulier, club, supporter). Nécessite KYC + scoring + monitoring distincts.
- **Conformité réglementaire lourde** : statut IOBSP (Intermédiaire en Opérations de Banque et Services de Paiement) requis côté France, agrément ACPR. Côté US : licence prêteur par État.
- **Coût d'industrialisation** : 3 mécaniques back-office distinctes au lieu d'une seule.

### Neutres

- Possibilité d'ajouter d'autres produits ultérieurement (crédit sociétaire COLHYBRI, crédit pratiquant DOJUKU bois équipement, etc.) — mais ces 3-là sont **constitutifs** par définition.

## Alternatives considered

| Alternative | Pourquoi écartée |
|---|---|
| **Un seul produit unique (crédit conso généraliste)** | Perte de l'ancrage sectoriel sport/culture, brouillage du message |
| **Pas de crédit du tout, paiement comptant uniquement** | Brise la mission "démocratisation accès". Élimine la barrière supporter 150$ d'un coup. |
| **Partenariat avec un acteur crédit conso existant (Cetelem, Younited)** | Perte de la maîtrise marge + perte d'opportunité fundraising groupe |
| **Crédit revolving** | Pratiques perçues comme prédatrices, incompatibles doctrine ONLYMORE |
| **5+ produits dès le départ** | Trop de surface, complexité industrialisation, dilution du focus |

## Garde-fous

- **Aucun crédit revolving** ni mécanique d'usure.
- **Adossement explicite** sur flux récurrents (CROWNIUM fan capital, abonnements licence) pour minimiser le risque.
- **Garantie collective mutualiste** sur Première mensualité supporter (le pool mutualiste absorbe le risque marginal de défaut).
- **Compliance ACPR + IOBSP** : prérequis indispensable avant tout déploiement FR.

## Implémentation

- **Phase 1 (M0 → M6)** : design produit + modélisation risque + démarche agrément IOBSP / ACPR.
- **Phase 2 (M6 → M12)** : MVP backend (Supabase + edge functions + connexion paiement Stripe / GoCardless).
- **Phase 3 (M12 → M18)** : pilote Pay For Play sur clubs CROWNIUM Tier Dev (US Créteil-Lusitanos, Béliers).
- **Phase 4 (M18 → M24)** : ouverture des 3 produits + reporting consolidé via Carta/Pulley.

## Revue

- **M+6** : statut agrément IOBSP, jalons réglementaires.
- **M+12** : retour pilote Pay For Play (taux de défaut, satisfaction utilisateurs).
- **M+24** : revue complète des 3 produits, ajustements pricing / scoring / garanties.

---

*ADR-005 v1.0 — décidé le 13 mai 2026.*
