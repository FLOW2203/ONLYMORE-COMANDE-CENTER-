---
title: "ADR-003 — COLHYBRI : pricing double face sociétaires + commerçants"
date: 2026-05-13
type: adr
status: Accepted
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/adr
  - onlymore/filiale/colhybri
  - onlymore/pricing
related:
  - "[[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3]]"
  - "[[ADR-002-architecture-cascade-mutualiste-spv]]"
---

# ADR-003 — COLHYBRI : pricing double face sociétaires + commerçants

## Status

**Accepted** — 13/05/2026.

## Context

COLHYBRI est la filiale SaaS de solidarité de quartier d'ONLYMORE Group (caffè sospeso digital). Slogans : *« Chaque geste compte. Le vôtre aussi. »* / *« Own Your Neighborhood. Own Your Future. »*

La filiale doit générer du MRR récurrent qui alimente la Cascade Mutualiste SPV (cf. ADR-002), et tenir une mécanique mutualiste calée sur les modèles MAIF / MACIF (220 ans d'héritage mutualiste français).

Question pricing : freemium ? Tarif unique ? Marketplace fee ? Double face ?

## Decision

Adopter un **modèle de pricing double face** :

| Cible | Formule | Tarif | Avantage |
|---|---|---|---|
| Particuliers | Basic | **3$ / mois** | Accès écosystème mutualiste, alimente le pot commun |
| Commerçants | Standard | **10$ / mois** | 0% commission sur ventes, visibilité réseau |
| Commerçants | Premium Maps+ | **15$ / mois** | Standard + Carte Cadeau + premium mapping |

### Règle non-négociable

> **COLHYBRI n'est jamais gratuit côté client.** Aucun freemium. Aucun pilote gratuit. CTA = « Réserver un rendez-vous », jamais « Souscrire ».

### Mécanique mutualiste

100 000 sociétaires × 3$/mois = **3,6 M$/an** de masse mutualisée qui finance le réseau et soutient les commerces participants.

### Marché US (cas de référence Cascade SPV)

| Cible US | Volume | Tarif | Pénétration 1% | MRR |
|---|---|---|---|---|
| Particuliers | 330 M habitants | 3$/mois | 3,3 M sociétaires | 9,9 M$/mois |
| Commerçants | 38 M small businesses | 10$/mois | 380 K | 3,8 M$/mois |
| **Total** | — | — | **3,68 M sociétaires** | **13,7 M$/mois — 164,4 M$/an** |

## Consequences

### Positives

- **Double monétisation symétrique** : les deux côtés du marché paient, alignement d'intérêts.
- **MRR récurrent prévisible** : abonnements > commissions transactionnelles (moins de volatilité).
- **Crédibilité mutualiste** : payer = être sociétaire investisseur, pas consommateur passif. Cohérent doctrine ONLYMORE.
- **Filtre qualité** : pas de freemium = audience auto-sélectionnée motivée.
- **Marge nette élevée** : 0% commission côté commerçants = pas de friction transactionnelle, simplicité comptable.
- **Compatibilité Cascade SPV** : MRR mensuel = injection mensuelle dans les SPV.

### Négatives

- **Acquisition plus lente** vs freemium : pas de TOFU large gratuit.
- **Friction onboarding** : il faut prendre un RDV plutôt que tester gratuitement → CAC potentiellement plus élevé.
- **Concurrents gratuits visibles** (Nextdoor, communautés Facebook) : difficile à concurrencer en perception "économique" à court terme.

### Neutres

- Tarif aligné sur les références mutualistes (MAIF cotisation membre).
- Pas de tarif dégressif au volume sociétaires : la masse mutualisée alimente directement les services, pas l'opérateur.

## Alternatives considered

| Alternative | Pourquoi écartée |
|---|---|
| **Freemium côté particuliers** | Brise la doctrine mutualiste (payer = être investisseur). Génère du noise non-aligné. |
| **Commission sur transactions** | Volatilité MRR, complexité comptable, alignement boutique-COLHYBRI flou. |
| **Tarif unique côté commerçants (pas de Standard/Premium)** | Manque un upsell naturel, perte d'opportunité Premium Maps+ (15$). |
| **3$/an au lieu de 3$/mois côté particuliers** | MRR/mois trop faible (36$/an seulement → trop petit pour alimenter SPV mensuel). |
| **5$ ou 7$ côté particuliers** | Barrière à l'entrée trop forte sur des quartiers populaires (cible Rust Belt US). |
| **Pilote gratuit 3 mois** | Brise la règle "jamais gratuit". Casse la dynamique sociétaire. |

## Implémentation

- App COLHYBRI à concevoir avec mécanique double face dès le MVP.
- CTA frontend : « Réserver un rendez-vous » (rendez-vous = onboarding doctrinal).
- Funnel : RDV → présentation mécanique mutualiste → souscription en présentiel ou téléphonique.
- Backend Supabase : table `subscribers` (particuliers) + `merchants` (commerçants, 2 tiers : Standard / Premium).

## Revue

- **M+6** : retour data sur taux de conversion RDV → souscription. Si <20%, revisiter le tunnel.
- **M+12** : test A/B sur le pricing particuliers (3$ vs 4$) sur un échantillon.

---

*ADR-003 v1.0 — décidé le 13 mai 2026.*
