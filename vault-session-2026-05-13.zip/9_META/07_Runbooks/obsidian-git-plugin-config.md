---
title: "Runbook — Configuration plugin Obsidian Git (vinzent03)"
date: 2026-05-13
type: runbook
status: v1.0
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/runbook
  - onlymore/obsidian/plugin
  - onlymore/vault
related:
  - "[[obsidian-vault-setup]]"
  - "[[gpg-key-generation]]"
---

# Runbook — Configuration plugin Obsidian Git (vinzent03)

> **Plugin** : Obsidian Git par vinzent03, version 2.38.2 (installée le 13/05/2026).
> **Objectif** : sync automatique du vault vers `FLOW2203/onlymore-vault` sans intervention manuelle.
> **Durée setup** : 5 min.

## 1. Installation

1. Obsidian → Settings → Community plugins → **Turn on community plugins**
2. Browse → rechercher "Obsidian Git" → Install
3. Une fois installé : Enable
4. Vérifier version dans la liste : **2.38.2** (au 13/05/2026)

## 2. Les 8 settings à activer

Ouvrir Settings → Obsidian Git, puis configurer :

| # | Setting | Valeur | Justification |
|---|---|---|---|
| 1 | **Auto pull on startup** | ✅ ON | Récupère les modifs des autres machines en début de session |
| 2 | **Auto push on close** | ✅ ON | Garantit qu'aucune modif ne reste localement à la fermeture |
| 3 | **Vault backup interval (minutes)** | `30` | Auto-commit toutes les 30 min — granularité raisonnable |
| 4 | **Auto pull interval (minutes)** | `60` | Sync entrante moins fréquente, évite latence sur grosse session |
| 5 | **Commit message** | `vault: sync {{date}}` (format `YYYY-MM-DD HH:mm:ss`) | Messages traçables, datés |
| 6 | **Disable on this device** | ❌ OFF | Activé sur cette machine |
| 7 | **Sync method** | `Pull-Push` (pas Rebase, pas Merge) | Le plus simple, conflits rares en mode solo |
| 8 | **Show status bar** | ✅ ON | Voir l'état sync en bas d'écran (utile pour debug) |

## 3. Compatibilité avec git-crypt + GPG

### Problème connu

Le plugin Obsidian Git invoque `git commit` qui, sur fichiers `filter=git-crypt`, peut déclencher `gpg --decrypt` lors du processus. Si `gpg-agent` n'a pas la passphrase en cache, **le commit se bloque silencieusement** (Obsidian n'a pas de terminal pour le prompt pinentry).

### Mitigation appliquée

Dans `~/.gnupg/gpg-agent.conf` :

```
default-cache-ttl 28800
max-cache-ttl 28800
```

Puis :

```bash
gpgconf --kill gpg-agent
gpg-agent --daemon
```

→ Passphrase saisie une fois en début de journée (par `gpg --list-secret-keys` ou un commit terminal), valide 8 h.

### Workflow journalier

1. **Matin** : ouvrir Git Bash, taper :
   ```bash
   echo "warm-up" | gpg --sign --local-user onlymore2024@gmail.com > /dev/null
   ```
   → demande de passphrase, mise en cache pour 8 h.
2. **Journée** : ouvrir Obsidian. Travailler normalement. Le plugin commit/push tout seul.
3. **Soir** : fermer Obsidian (auto-push final déclenché).

## 4. Vérifications post-config

### 4.1 Test auto-pull

Modifier un fichier sur GitHub directement (via interface web, un fichier non sensible), puis fermer + rouvrir Obsidian. Le fichier doit apparaître modifié dans le vault.

### 4.2 Test auto-commit

Créer un nouveau fichier `8_DAILY/test.md`, attendre 30 min (ou forcer via la palette de commandes : `Obsidian Git: Commit all changes`). Vérifier que le commit apparaît dans l'historique git :

```bash
cd /c/ONLYMORE/00_HOLDING
git log --oneline -5
```

### 4.3 Test auto-push on close

Fermer Obsidian via menu File → Quit (pas `Ctrl+C`). Vérifier sur GitHub que le dernier commit est apparu sans intervention manuelle.

## 5. Status bar : que regarder

Le status bar Obsidian Git affiche :

- **N changes** : nb de fichiers modifiés non commités
- **Last commit** : timestamp du dernier auto-commit
- **Pulled / Pushed** : statut sync remote

Si tu vois `N changes` qui ne diminue pas après l'intervalle de 30 min → blocage (probablement passphrase GPG perdue). Solution : ré-amorcer le cache passphrase via Git Bash.

## 6. Désactivations explicites

- ❌ **Ne pas activer** « Auto commit-and-sync » si tu n'as pas configuré le TTL `gpg-agent` (sinon blocages réguliers).
- ❌ **Ne pas activer** « Custom git binary path » sauf cas particulier — laisser le plugin trouver Git automatiquement.

## Troubleshooting

| Symptôme | Cause | Solution |
|---|---|---|
| Commits arrêtent après 30 min | Cache passphrase expiré | Augmenter TTL ou ré-amorcer |
| Push échoue `Authentication failed` | Token GitHub périmé | Refaire `gh auth login` |
| Conflits fréquents | 2 machines syncent simultanément | Désactiver auto-push sur la machine secondaire, sync manuelle |
| Status bar absente | Setting #8 désactivé | Réactiver Show status bar |
| Plugin ne démarre pas | Vault pas un repo git | Vérifier `git status` dans le vault |

## Notes ONLYMORE

- Plugin auto-update : activer dans Settings → Community plugins → cliquer sur "Check for updates" 1× / mois.
- Si évolution majeure du plugin (passage v3.x) : tester sur clone du vault avant production.

## Suite

- Setup complet vault : [[obsidian-vault-setup]]
- Génération clé GPG : [[gpg-key-generation]]

---

*Runbook v1.0 — Florent Gibert, 13 mai 2026.*
