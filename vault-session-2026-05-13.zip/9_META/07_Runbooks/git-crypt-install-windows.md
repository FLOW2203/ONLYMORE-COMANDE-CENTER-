---
title: "Runbook — Installation git-crypt sous Windows 11 + Git Bash"
date: 2026-05-13
type: runbook
status: v1.0
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/runbook
  - onlymore/securite/git-crypt
  - onlymore/install/windows
related:
  - "[[obsidian-vault-setup]]"
  - "[[gpg-key-generation]]"
---

# Runbook — Installation git-crypt sous Windows 11 + Git Bash

> Procédure d'installation de `git-crypt` sur Windows 11 (machine de Rodilhan). Trois méthodes par ordre de préférence : Scoop (recommandée, méthode utilisée le 13/05/2026), binaire manuel, ou compilation.
> **Durée** : 2 min via Scoop.

## Méthode 1 — Scoop (recommandée, exécutée le 13/05/2026)

### 1.1 Prérequis : Scoop installé

Vérifier dans PowerShell :

```powershell
scoop --version
```

Si absent, installer Scoop (à exécuter dans PowerShell **non-admin**) :

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
irm get.scoop.sh | iex
```

### 1.2 Installer git-crypt

```powershell
scoop install git-crypt
```

### 1.3 Vérifier dans Git Bash

```bash
git-crypt --version
```

Sortie attendue : `git-crypt 0.7.0` (ou version supérieure).

## Méthode 2 — Binaire manuel (si Scoop indisponible)

### 2.1 Télécharger

Page release officielle : https://github.com/AGWA/git-crypt/releases

Choisir le binaire `git-crypt-X.Y.Z-x86_64.exe`.

### 2.2 Placer dans le PATH Git Bash

Copier le binaire (renommé en `git-crypt.exe`) vers :

```
/c/Program Files/Git/usr/bin/git-crypt.exe
```

Redémarrer Git Bash.

### 2.3 Vérifier

```bash
git-crypt --version
which git-crypt
```

## Méthode 3 — Compilation depuis source (cas extrême)

> À éviter sauf si Scoop et binaire pré-compilé ne fonctionnent pas. Nécessite MSYS2 + chaîne C++.

```bash
# Dans MSYS2
pacman -S mingw-w64-x86_64-openssl mingw-w64-x86_64-gcc make
git clone https://github.com/AGWA/git-crypt.git
cd git-crypt
make CXX=g++ LDFLAGS=-static
cp git-crypt.exe /c/Program\ Files/Git/usr/bin/
```

## Test post-install

Dans un dossier de test (PAS le vault de production) :

```bash
mkdir /tmp/git-crypt-test
cd /tmp/git-crypt-test
git init
git-crypt init
echo "secret" > secret.txt
echo "secret.txt filter=git-crypt diff=git-crypt" > .gitattributes
git add -A
git commit -m "test"
git-crypt lock
cat secret.txt  # → contenu binaire chiffré
git-crypt unlock
cat secret.txt  # → "secret" en clair
```

Si les deux `cat` retournent bien binaire puis clair → install OK.

## Troubleshooting

| Symptôme | Cause probable | Solution |
|---|---|---|
| `git-crypt: command not found` | Pas dans le PATH Git Bash | Vérifier `/c/Program Files/Git/usr/bin/` |
| `git-crypt init` → segfault | Version trop ancienne | Réinstaller via Scoop (`scoop update git-crypt`) |
| `git-crypt add-gpg-user` → `gpg: skipped: No public key` | Clé GPG pas générée | Voir [[gpg-key-generation]] |
| Permission denied sur `/c/Program Files/Git/usr/bin/` | Pas admin | Lancer PowerShell en admin pour copier le binaire |

## Notes Florent

- Sur la machine de Rodilhan, Scoop a été choisi pour : (a) auto-update, (b) cohérence avec d'autres outils déjà installés via Scoop, (c) zéro friction admin (install user-scope).
- Version installée le 13/05/2026 : `git-crypt 0.7.0`.

## Suite

- Génération clé GPG : [[gpg-key-generation]]
- Setup vault complet : [[obsidian-vault-setup]]

---

*Runbook v1.0 — Florent Gibert, 13 mai 2026.*
