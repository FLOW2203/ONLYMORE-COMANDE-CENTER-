---
title: "Runbook — Génération clé GPG ONLYMORE"
date: 2026-05-13
type: runbook
status: v1.0
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/runbook
  - onlymore/securite/gpg
related:
  - "[[obsidian-vault-setup]]"
  - "[[git-crypt-install-windows]]"
  - "[[secrets-management]]"
  - "[[ADR-001-vault-obsidian-chiffrement-at-rest]]"
---

# Runbook — Génération clé GPG ONLYMORE

> **Procédure stand-alone** — Génère une clé GPG RSA 4096 dédiée ONLYMORE Group, utilisable pour `git-crypt`, signatures `git commit -S`, chiffrement email vers le board.
> **Durée** : 3-5 min.
> **À faire une seule fois par identité.**

## Pré-requis

- GPG 2.4.x+ installé (vérifier : `gpg --version`).
- Passphrase forte choisie à l'avance, à stocker dans un password manager (1Password, Bitwarden, KeePass).
- Email pro : `onlymore2024@gmail.com`.

## 1. Vérifier l'absence de clé existante

```bash
gpg --list-secret-keys onlymore2024@gmail.com
```

- Si une clé existe et n'expire pas : passer directement à la sauvegarde (étape 4).
- Si rien : continuer.

## 2. Génération interactive

```bash
gpg --full-generate-key
```

Réponses à donner :

| Question | Réponse |
|---|---|
| Type de clé | `1` (RSA and RSA) — **recommandé pour compatibilité git-crypt** |
| Taille | `4096` |
| Validité | `0` (n'expire jamais) |
| Confirmation | `y` |
| Real name | `Florent Gibert` |
| Email | `onlymore2024@gmail.com` |
| Comment | `ONLYMORE Group Vault Master Key` |
| Confirmation finale | `O` (Okay) |
| Passphrase | (choisie au préalable, stockée password manager) |

> **Pourquoi RSA et pas ECC ?** ECC (Curve25519/ed25519) génère des erreurs de compatibilité sur certaines versions de `git-crypt` Windows. RSA 4096 = standard universel.

## 3. Vérification post-génération

```bash
gpg --list-secret-keys --keyid-format=long onlymore2024@gmail.com
```

Sortie attendue :
```
sec   rsa4096/XXXXXXXXXXXXXXXX 2026-05-13 [SC]
      FC622EB8056509B4BBC4B436E47ADD21CC605948
uid           [ultimate] Florent Gibert (ONLYMORE Group Vault Master Key) <onlymore2024@gmail.com>
ssb   rsa4096/YYYYYYYYYYYYYYYY 2026-05-13 [E]
```

**Empreinte produite cette session ONLYMORE** : `FC622EB8056509B4BBC4B436E47ADD21CC605948`.

## 4. Sauvegarde critique de la clé

```bash
mkdir -p /c/ONLYMORE/00_SAFE_KEYS
gpg --export-secret-keys --armor onlymore2024@gmail.com > /c/ONLYMORE/00_SAFE_KEYS/onlymore-master-key-private.asc
gpg --export --armor onlymore2024@gmail.com > /c/ONLYMORE/00_SAFE_KEYS/onlymore-master-key-public.asc
```

**Copier `00_SAFE_KEYS/` sur 2 supports physiques différents** :

- Support 1 : clé USB chiffrée VeraCrypt, dans coffre.
- Support 2 : cloud privé chiffré (rclone crypt + Backblaze B2 / iDrive).

Sans cette redondance, **perte machine = perte définitive de toute la doctrine chiffrée**.

## 5. Configuration cache passphrase (optionnel mais recommandé)

Pour éviter de retaper la passphrase à chaque opération git-crypt / commit signé :

```bash
mkdir -p ~/.gnupg
cat > ~/.gnupg/gpg-agent.conf <<'EOF'
default-cache-ttl 28800
max-cache-ttl 28800
EOF

# Redémarrer l'agent
gpgconf --kill gpg-agent
gpg-agent --daemon
```

TTL 8 h = saisie une fois le matin, valide toute la journée de travail.

## 6. Test de chiffrement / déchiffrement

```bash
echo "test ONLYMORE" | gpg --encrypt --armor --recipient onlymore2024@gmail.com | gpg --decrypt
```

Sortie attendue : `test ONLYMORE` (avec demande de passphrase au premier appel).

## Garde-fous

| Règle | Justification |
|---|---|
| Jamais commit `00_SAFE_KEYS/` ni la clé privée | `.gitignore` doit l'exclure |
| Passphrase notée dans password manager **uniquement** | Pas de post-it, pas de note plain text |
| Clé sans expiration | Évite le risque d'expiration silencieuse au pire moment |
| Une clé par identité | Pas de réutilisation entre projets personnels / pro / autres entités |

## Troubleshooting

| Erreur | Solution |
|---|---|
| `gpg: agent_genkey failed: No such file or directory` | `gpgconf --kill gpg-agent && gpg-agent --daemon` puis relancer |
| Pas assez d'entropie | Bouger la souris / taper du texte au clavier pendant la génération |
| Passphrase oubliée | **Aucune récupération possible** — régénérer la clé et re-chiffrer tout |

## Suite

- Setup git-crypt : voir [[obsidian-vault-setup]] Phase 5.
- Install git-crypt sur Windows : [[git-crypt-install-windows]].
- Doctrine secrets ONLYMORE : [[secrets-management]].

---

*Runbook v1.0 — Florent Gibert, 13 mai 2026.*
