---
title: "Runbook — Setup vault Obsidian + git-crypt + GitHub privé"
date: 2026-05-13
type: runbook
status: v1.0
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/runbook
  - onlymore/securite/git-crypt
  - onlymore/securite/gpg
  - onlymore/vault
related:
  - "[[gpg-key-generation]]"
  - "[[git-crypt-install-windows]]"
  - "[[obsidian-git-plugin-config]]"
  - "[[ADR-001-vault-obsidian-chiffrement-at-rest]]"
  - "[[2026-05-13-Session-Marathon-Vault-Crypto]]"
---

# Runbook — Setup vault Obsidian + git-crypt + GitHub privé

> **Runbook validé** — 13/05/2026. Exécuté avec succès sur la machine de Rodilhan.
> **Durée** : 15 min.
> **Pré-requis** : Git Bash, GPG 2.4.9+, `gh` CLI authentifié, plugin Obsidian Git installé.
> **Référence transverse** : PR #10 du repo `ONLYMORE-COMANDE-CENTER-` (version canonique du runbook côté command-center).

## Phase 1 — Sauvegarde de l'état actuel (2 min)

```bash
cd /c/ONLYMORE/00_HOLDING
git stash push -u -m "snapshot-pre-cli-setup-$(date +%Y%m%d-%H%M)"
git stash list
```

Sortie attendue : `stash@{0}: On main: snapshot-pre-cli-setup-20260513-1510`

## Phase 2 — Clé GPG (3 min)

Voir runbook dédié : [[gpg-key-generation]].

Empreinte produite cette session : `FC622EB8056509B4BBC4B436E47ADD21CC605948`.

## Phase 3 — Repo distant + remote (1 min)

```bash
gh repo create FLOW2203/onlymore-vault \
  --private \
  --description "ONLYMORE Group — Obsidian vault (doctrine, IP, CRM, briefs CFO)"

cd /c/ONLYMORE/00_HOLDING
git remote add origin https://github.com/FLOW2203/onlymore-vault.git
git remote -v
```

## Phase 4 — `.gitignore` Obsidian-aware (1 min)

```bash
cat > .gitignore <<'EOF'
# Obsidian workspace
.obsidian/workspace*
.obsidian/cache/
.obsidian/graph.json
.obsidian/app.json
.obsidian/appearance.json
.obsidian/hotkeys.json
# Système
.trash/
.DS_Store
Thumbs.db
desktop.ini
# Temporaires
*.tmp
*~
.~lock.*
# Sécurité
*.key
*.pem
.env*
00_SAFE_KEYS/
# Backups
*.bak
*.backup
EOF

git rm --cached .obsidian/core-plugins.json .obsidian/graph.json .obsidian/workspace.json 2>/dev/null || true
git add .gitignore
git commit -m "chore: add Obsidian-aware .gitignore + remove workspace files from tracking"
```

## Phase 5 — git-crypt sur dossiers sensibles (3 min)

Install Windows : voir [[git-crypt-install-windows]].

```bash
git-crypt init
git-crypt add-gpg-user onlymore2024@gmail.com

cat > .gitattributes <<'EOF'
9_META/00_Constitutions/** filter=git-crypt diff=git-crypt
9_META/05_CFO_Briefs/** filter=git-crypt diff=git-crypt
9_META/06_Doctrine_Sensible/** filter=git-crypt diff=git-crypt
6_CRM/** filter=git-crypt diff=git-crypt
9_META/**/README.md !filter !diff
9_META/**/_INDEX.md !filter !diff
EOF

git add .gitattributes
git commit -m "feat(security): setup git-crypt on sensitive folders"
```

## Phase 6 — Dépôt des fichiers constitutionnels (3 min)

```bash
mkdir -p 9_META/00_Constitutions
cd /c/ONLYMORE/00_HOLDING/9_META/00_Constitutions
unzip /c/Users/Moi/Downloads/00-constitutions-financieres-onlymore.zip
ls -la
```

### 6c. Vérification filtre actif

```bash
cd /c/ONLYMORE/00_HOLDING
git check-attr filter -- 9_META/00_Constitutions/2026-05-13-Cascade-Mutualiste-SPV-Constitution-3.md
```

Sortie attendue : `filter: git-crypt`.

### 6d. Garde-fou audit couverture chiffrement

```bash
git add -A
git ls-files --cached | xargs -I {} sh -c 'echo "=== {} ==="; git check-attr filter -- "{}"' \
  | grep -E 'Constitutions|CFO_Briefs|Doctrine_Sensible|CRM' \
  | grep -v 'filter: git-crypt'
```

Sortie attendue : **aucune ligne**. Une ligne = fichier sensible sans filtre → corriger `.gitattributes`.

## Phase 7 — Premier commit + push chiffré (1 min)

```bash
git add 9_META/00_Constitutions/
git commit -m "feat(doctrine): add 3rd Financial Constitution + 6 associated stubs"
git push -u origin main
```

## Phase 8 — Récupérer le stash (1 min)

```bash
git stash pop
git status
```

## Phase 9 — Vérification chiffrement (1 min)

### 9a. Vue distante (GitHub)

Ouvrir : `https://github.com/FLOW2203/onlymore-vault/blob/main/9_META/00_Constitutions/2026-05-13-Cascade-Mutualiste-SPV-Constitution-3.md`

Attendu : binaire illisible commençant par `GITCRYPT…`. Si markdown en clair visible → **arrêt immédiat**.

### 9b. Vue locale

```bash
cat 9_META/00_Constitutions/2026-05-13-Cascade-Mutualiste-SPV-Constitution-3.md | head -20
```

Attendu : frontmatter YAML en clair.

### 9c. `git-crypt status`

> **Note** : ne montre `encrypted` qu'**après** le commit Phase 7. Avant, tout apparaît `not encrypted` — c'est normal.

```bash
git-crypt status
```

## Phase 10 — Workflow quotidien

Voir runbook dédié : [[obsidian-git-plugin-config]].

## Garde-fous non-négociables

| Règle | Justification |
|---|---|
| Jamais commit `00_SAFE_KEYS/` | Push de la clé privée = chiffrement caduc |
| Backup clé GPG sur 2 supports physiques distincts | Perte clé = perte définitive doctrine chiffrée |
| Vérifier après chaque push : binaire sur GitHub | Test régulier du chiffrement |
| Ajout João Almeida comme git-crypt user uniquement en présentiel | Cohérence règle "engagements en présentiel" |

## Troubleshooting

| Symptôme | Solution |
|---|---|
| `git-crypt: command not found` | Voir [[git-crypt-install-windows]] |
| `gpg: keyserver receive failed` | `--keyserver hkps://keys.openpgp.org` |
| Fichier en clair sur GitHub | `git-crypt status` + force re-encrypt |
| Push refusé `Updates were rejected` | `git pull --rebase` puis re-push |
| Plugin Obsidian Git auto-commit bloqué | Augmenter TTL `gpg-agent` (voir [[obsidian-git-plugin-config]]) |

---

*Runbook v1.0 — exécuté avec succès le 13 mai 2026.*
