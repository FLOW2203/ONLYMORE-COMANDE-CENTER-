---
title: "Index — CFO Briefs ONLYMORE Group"
date: 2026-05-13
type: index
status: active
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/cfo
  - onlymore/index
related:
  - "[[2026-05-13-Brief-CFO-Joao-Almeida-2026-05]]"
  - "[[_MOC-Constitutions-Financieres]]"
---

# Index — CFO Briefs ONLYMORE Group

> **Note** — Ce README reste lisible (exempté de chiffrement via la règle `9_META/**/README.md !filter !diff` du `.gitattributes`). **Tous les autres fichiers de ce dossier sont chiffrés at-rest via git-crypt + GPG RSA 4096 (empreinte `FC622EB8056509B4BBC4B436E47ADD21CC605948`).**

## Objet du dossier

Briefs préparatoires aux réunions avec João Almeida (CFO ONLYMORE Group, ex-ONEtoONE Corporate Finance). Chaque brief suit le format trame opérationnelle 1-page :

- 3 points-clé techniques à valider
- Chiffres-clé à mémoriser
- Agenda 45 min présentiel
- Output attendu

## Convention de nommage

Format : `YYYY-MM-DD-Brief-CFO-Joao-Almeida-AAAA-MM.md`

## Garde-fou

> **Toute proposition de contrat, signature ou engagement structurant se fait en présentiel uniquement.** Les briefs sont des supports de réunion de travail (validation technique), jamais des lettres signées à distance.

## Briefs archivés

| Date | Brief | Statut |
|---|---|---|
| 2026-05-13 | [[2026-05-13-Brief-CFO-Joao-Almeida-2026-05]] (archivé dans `00_CONSTITUTIONS/`) | stub enrichi, à envoyer |

## Briefs à venir

- M+1 : retour sur réunion Cascade Mutualiste SPV (validation Delaware LLC + premières banques privées priorisées)
- M+3 : pré-revue upgrade v1.0 des 4 stubs constitutionnels
- M+6 : audit KYC-Master ONLYMORE pré-Phase 2 (RFP cabinets juridiques)

---

*Index institué le 13 mai 2026. ONLYMORE Group.*
