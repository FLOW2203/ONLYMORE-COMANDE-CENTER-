---
title: "Index — Doctrine Sensible ONLYMORE Group"
date: 2026-05-13
type: index
status: active
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/doctrine/sensible
  - onlymore/index
related:
  - "[[_MOC-Constitutions-Financieres]]"
  - "[[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3]]"
---

# Index — Doctrine Sensible ONLYMORE Group

> **Note** — Ce README reste lisible (exempté de chiffrement via la règle `9_META/**/README.md !filter !diff` du `.gitattributes`). **Tous les autres fichiers de ce dossier sont chiffrés at-rest via git-crypt + GPG RSA 4096 (empreinte `FC622EB8056509B4BBC4B436E47ADD21CC605948`).**

## Objet du dossier

Documents doctrinaux sensibles d'ONLYMORE Group qui ne sont pas des constitutions financières formelles mais touchent à des sujets stratégiques nécessitant un chiffrement at-rest :

- Notes de positionnement concurrentiel
- Stratégies M&A et négociations en cours
- Méthodologies internes propriétaires (mode commando, doctrine additivité stricte)
- Roadmaps stratégiques pluriannuelles non communicables externes
- Réflexions doctrinales pré-formalisation (avant passage en `00_CONSTITUTIONS/`)
- Mémos internes à diffusion restreinte (board, advisor, fondateur uniquement)

## Convention de nommage

Format : `YYYY-MM-DD-Titre-Kebab-Case.md`

## Tags hiérarchiques applicables

- `#onlymore/doctrine/sensible`
- `#onlymore/strategie/m-and-a`
- `#onlymore/positionnement/concurrentiel`
- `#onlymore/board`
- `#onlymore/advisor`

## Workflow type

1. Rédaction dans ce dossier (chiffré automatiquement au commit)
2. Validation interne CEO ± Board Advisor (Michel Nilles)
3. Si pertinent : promotion en `00_CONSTITUTIONS/` (formalisation publique-board)
4. Sinon : archivage long terme avec statut `archived`

## Documents à venir (placeholder)

| Date | Document | Statut |
|---|---|---|
| À venir | Note positionnement concurrentiel COLHYBRI vs Nextdoor / Patreon / GoFundMe | draft |
| À venir | Stratégie M&A clubs sportifs (CROWNIUM Tier Dev pipeline US Créteil-Lusitanos, Béliers) | draft |
| À venir | Doctrine additivité stricte — règles internes de communication | draft |

---

*Index institué le 13 mai 2026. ONLYMORE Group.*
