---
title: "Session Marathon Vault Crypto — 13 mai 2026"
date: 2026-05-13
type: session
status: archived
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/session/marathon
  - onlymore/doctrine/finance
  - onlymore/securite/vault
  - onlymore/securite/git-crypt
related:
  - "[[2026-05-13]]"
  - "[[2026-05-13-Cascade-Mutualiste-SPV-Constitution-3]]"
  - "[[_MOC-Constitutions-Financieres]]"
  - "[[ADR-001-vault-obsidian-chiffrement-at-rest]]"
  - "[[ADR-002-architecture-cascade-mutualiste-spv]]"
  - "[[obsidian-vault-setup]]"
---

# Session Marathon Vault Crypto — 13 mai 2026

> Session de 5 h ayant produit 10 livrables stratégiques structurants pour ONLYMORE Group : la 3ᵉ Constitution Financière + l'infrastructure de protection at-rest de la doctrine.

## Objectif initial

Formaliser la doctrine Cascade Mutualiste SPV en document constitutionnel exploitable (brief CFO, board, investors), et la protéger techniquement avant toute diffusion externe.

## Résultat obtenu

Doctrine financière intégrale (triptyque constitutionnel) **rédigée + versionnée + chiffrée at-rest** + infrastructure vault Obsidian opérationnelle pour la suite (CFO briefs, doctrine sensible, CRM stratégique).

## Récap exhaustif des 10 livrables

### Bloc A — Doctrine financière (livrables 1 à 6)

1. **Cascade Mutualiste SPV — 3ᵉ Constitution Financière** (`2026-05-13-Cascade-Mutualiste-SPV-Constitution-3.md`)
   - 615 lignes, version 1.0 draft constitutionnel
   - 11 sections (préambule, groupe, modèles par filiale, doctrine SPV, architecture juridique, 7 avantages, chiffres-clé COLHYBRI USA, garde-fous CFO, articulation filiales, roadmap, annexes)
   - Trio constitutionnel posé : Capital Sociétaire Inaliénable · Double Boucle Infinie · Cascade SPV

2. **Stub Constitution Double Boucle Infinie** (`2026-05-13-Constitution-Double-Boucle-Infinie.md`)
   - 2ᵉ Constitution Financière, contenu déduit de Cascade SPV, à formaliser

3. **Stub Capital Sociétaire Inaliénable** (`2026-05-13-Capital-Societaire-Inalienable.md`)
   - 1ʳᵉ Constitution Financière, contenu déduit, héritage mutualiste 220 ans

4. **Stub Charte Bienveillance CROWNIUM** (`2026-05-13-Charte-Bienveillance-CROWNIUM.md`)
   - Cadre éthique fan capital, préservation 100% capital sportif clubs

5. **Stub Charte Fonds Services Suspendus** (`2026-05-13-Charte-Fonds-Services-Suspendus.md`)
   - Doctrine d'affectation, héritage caffè sospeso, ratio impact ×22

6. **MOC Constitutions Financières** (`_MOC-Constitutions-Financieres.md`)
   - Point d'entrée unique, tableau des 3 constitutions + chartes + briefs, convention de nommage et taxonomie de tags

### Bloc B — Briefs opérationnels (livrable 7)

7. **Brief CFO João Almeida (mai 2026)** (`2026-05-13-Brief-CFO-Joao-Almeida-2026-05.md`)
   - Note 1-page opérationnelle
   - 3 points-clé à valider : faisabilité Delaware LLC, coût/délai relations bancaires privées, compat ONEtoONE Corporate Finance
   - Agenda 45 min présentiel
   - Garde-fou : aucune signature à distance

### Bloc C — Infrastructure sécurité (livrables 8 à 10)

8. **Génération clé GPG RSA 4096** dédiée ONLYMORE
   - Empreinte : `FC622EB8056509B4BBC4B436E47ADD21CC605948`
   - UID : `Florent Gibert (ONLYMORE Group Vault Master Key) <onlymore2024@gmail.com>`
   - Sauvegarde sur 2 supports physiques distincts (clé USB + cloud privé)

9. **Setup git-crypt sur vault `C:\ONLYMORE\00_HOLDING\`**
   - Install via Scoop
   - Dossiers chiffrés : `9_META/00_CONSTITUTIONS/`, `9_META/05_CFO_Briefs/`, `9_META/06_Doctrine_Sensible/`, `6_CRM/`
   - Exceptions readables : `9_META/**/README.md`, `9_META/**/_INDEX.md`
   - Push initial chiffré vers `FLOW2203/onlymore-vault` (privé)

10. **Configuration Obsidian Git plugin** (vinzent03 v2.38.2)
    - 8 settings activés : auto-pull on startup, auto-push on close, auto-commit interval 30 min, etc.
    - Sync transparente, GPG cache TTL 8 h pour éviter blocage pinentry

## Métriques de session

| Métrique | Valeur |
|---|---|
| Durée effective | 5 h |
| Objets pushés (tous repos) | 81 |
| Volume net | 71,25 KiB |
| Commits sur `main` (vault) | 7 |
| Fichiers Markdown produits | 7 (constitutions/chartes/briefs) + ce dossier d'archivage |
| Repos GitHub touchés | 2 (`ONLYMORE-COMANDE-CENTER-`, `onlymore-vault`) |
| PR ouvertes | 2 (#8 zip artefact · #10 runbook permanent) |
| Clés GPG générées | 1 (RSA 4096) |
| Dossiers vault chiffrés | 4 |

## Empreintes SHA des commits clés

| SHA | Description (inférée) |
|---|---|
| `c146f51` | Setup .gitignore Obsidian-aware |
| `9c107fe` | Setup .gitattributes git-crypt |
| `5198517` | Init git-crypt + add-gpg-user |
| `4d392c7` | Dépôt des 7 fichiers constitutionnels chiffrés |
| `e791d72` | Configuration Obsidian Git plugin (commit local) |

## État final du vault

```
C:\ONLYMORE\00_HOLDING\
├── .git/                                   ← Versionning local
├── .gitignore                              ← Obsidian-aware
├── .gitattributes                          ← git-crypt config
├── .git-crypt/                             ← Clés de chiffrement (privé)
├── .obsidian/                              ← Config Obsidian (workspace exclu)
├── 1_PROJECTS/ … 8_DAILY/                  ← PARA standard
├── 9_META/
│   ├── 00_CONSTITUTIONS/    🔒 chiffré     ← 7 fichiers déjà déposés
│   ├── 04_Sessions/                        ← NOUVEAU (ce fichier)
│   ├── 05_CFO_Briefs/       🔒 chiffré
│   ├── 06_Doctrine_Sensible/ 🔒 chiffré
│   ├── 07_Runbooks/                        ← NOUVEAU (4 runbooks)
│   ├── 08_Architecture/                    ← NOUVEAU (4 docs + MOC)
│   └── 09_Decisions/                       ← NOUVEAU (5 ADR)
└── (autres fichiers vault…)

Remote : github.com/FLOW2203/onlymore-vault (privé, contenu chiffré at-rest)
```

## Diff état initial → état final

| Dimension | Avant session | Après session |
|---|---|---|
| Doctrine financière formalisée | 2 constitutions (orales, partagées) | 3 constitutions versionnées dont 1 complète |
| Vault Obsidian connecté à un remote | Non | Oui (privé, chiffré) |
| Chiffrement at-rest sur doctrine | Aucun | git-crypt + GPG RSA 4096 sur 4 dossiers |
| Runbook réutilisable de setup vault | Aucun | 1 runbook 10 phases versionné (PR #10) |
| Brief CFO João Almeida prêt à envoyer | Non | Oui (trame 45 min validée) |
| MOC de navigation du vault | Aucun | 1 MOC Constitutions Financières + 1 MOC Architecture |

## Anomalies / points de vigilance

- Plugin Obsidian Git + GPG passphrase : si TTL `gpg-agent` non augmenté, auto-commit toutes les 30 min peut se bloquer silencieusement. **Mitigation appliquée** : `default-cache-ttl 28800` dans `~/.gnupg/gpg-agent.conf`.
- 4 fichiers modifiés + 4 untracked dans le vault au démarrage de session : sécurisés via `git stash push -u`, repop en Phase 8 du runbook.
- Garde-fou ajouté en Phase 6d du runbook (audit couverture chiffrement) : non présent à l'exécution initiale, intégré au runbook permanent ensuite.

## Décisions ADR liées

- [[ADR-001-vault-obsidian-chiffrement-at-rest]]
- [[ADR-002-architecture-cascade-mutualiste-spv]]
- [[ADR-003-doctrine-colhybri-double-face-pricing]]
- [[ADR-004-dojuku-shingi-tarif-2usd-tam-520M]]
- [[ADR-005-onlymore-finance-3-produits-credit]]

## Suite à donner

1. Exécuter les 3 actions post-session 24-72 h (vérification chiffrement, backup clé GPG, envoi brief CFO).
2. Programmer revue M+3 (mi-août 2026) pour upgrade des 4 stubs constitutionnels en v1.0.
3. Décliner le runbook en variantes : `cfo-onboarding-git-crypt.md` (ajout João Almeida en présentiel) et `multi-machine-vault-deploy.md` (bootstrap 2ᵉ machine).

---

*Session clôturée le 13 mai 2026 à Rodilhan. Bilan archivé v1.0.*
