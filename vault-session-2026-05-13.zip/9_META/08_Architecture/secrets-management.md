---
title: "Doctrine de gestion des secrets ONLYMORE Group"
date: 2026-05-13
type: architecture
status: v1.0
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/architecture
  - onlymore/securite/secrets
  - onlymore/doctrine/securite
related:
  - "[[_MOC-Architecture-Technique-ONLYMORE]]"
  - "[[gpg-key-generation]]"
  - "[[obsidian-vault-setup]]"
  - "[[ADR-001-vault-obsidian-chiffrement-at-rest]]"
---

# Doctrine de gestion des secrets ONLYMORE Group

> Référence v1.0 — règles communes pour tout secret, clé, token, credential utilisé par ONLYMORE Group ou ses filiales.

## Catégories de secrets

| Catégorie | Exemples | Niveau de sensibilité |
|---|---|---|
| Clés maîtresses | GPG master vault, clés signing CI | **Critique** |
| Tokens API tiers | Supabase service role, Vercel deploy, GitHub PAT, Composio | Critique |
| Credentials utilisateur | Passwords admin Google / GitHub / Vercel / Stripe | Critique |
| Variables `.env` app | URLs publiques DB, clés anon (publiques) | Modéré |
| Secrets cosmétiques | Couleurs hexa, design tokens | Aucun |

## Règles fondamentales

1. **Aucun secret en clair dans un repo git**, jamais. Y compris dans l'historique. Si un secret fuit → rotation immédiate + `git filter-repo` pour purger l'historique.
2. **Aucun secret dans une note Obsidian non-chiffrée**. Si secret stratégique à archiver → dossier `9_META/06_Doctrine_Sensible/` (chiffré at-rest).
3. **Aucun secret dans un message Slack / Notion / email**. Échange exclusif via password manager partagé (1Password Team, Bitwarden Org) ou en présentiel.
4. **Rotation périodique** :
   - Tokens API : tous les 90 jours
   - Mot de passe admin : tous les 180 jours
   - Clé GPG master : pas de rotation (sans expiration) sauf compromission
5. **Backup clé GPG** : sur 2 supports physiques distincts (clé USB chiffrée VeraCrypt + cloud privé chiffré rclone crypt). Sans cette redondance, perte = perte définitive de toute la doctrine chiffrée.

## Stockage des secrets — matrice

| Secret | Stockage primaire | Stockage backup | Accès |
|---|---|---|---|
| Clé GPG master ONLYMORE (empreinte `FC622EB8056509B4BBC4B436E47ADD21CC605948`) | Keyring GPG machine Rodilhan | `00_SAFE_KEYS/` × 2 supports | CEO uniquement |
| Tokens Supabase / Vercel / Notion / etc. | Variables d'env Vercel (prod) + `.env.local` (dev, non commit) | Password manager | CEO + dev futurs (par filiale) |
| Passphrases password manager | Master password mental | Phrase de récupération imprimée, coffre physique | CEO uniquement |
| GitHub PAT | GitHub settings → Personal access tokens | Password manager | CEO + Claude Code (token dédié, scope limité) |
| OAuth tokens Composio LinkedIn | Composio dashboard, auto-refresh | n/a (régénération via re-auth) | CEO |

## Pattern `.env` ONLYMORE

```
# .env.example (commité, pas de vraies valeurs)
NEXT_PUBLIC_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR-ANON-KEY
SUPABASE_SERVICE_ROLE_KEY=YOUR-SERVICE-ROLE-KEY  # CRITIQUE - jamais côté client
GITHUB_TOKEN=ghp_...
NOTION_API_KEY=secret_...
```

**Règle** : tout `.env.local` ou `.env` réel est dans `.gitignore` du repo. `.env.example` documente la structure sans valeurs.

## Pattern git-crypt pour le vault

Dossiers chiffrés sur le vault Obsidian (cf. `.gitattributes`) :

- `9_META/00_CONSTITUTIONS/`
- `9_META/05_CFO_Briefs/`
- `9_META/06_Doctrine_Sensible/`
- `6_CRM/`

Exceptions readables : `9_META/**/README.md`, `9_META/**/_INDEX.md`.

## Ajout d'un collaborateur git-crypt

- **CFO João Almeida** : ajout uniquement après réunion présentielle (règle "engagements en présentiel").
- Procédure : `git-crypt add-gpg-user <email>` puis commit + push. João doit avoir importé sa clé GPG publique au préalable.

## Scan secrets pré-commit

Hook recommandé `.git/hooks/pre-commit` :

```bash
#!/usr/bin/env bash
PATTERNS='sk-|ghp_|eyJ|AIza|glpat-|BEGIN PRIVATE KEY|service_role'
if git diff --cached | grep -E "$PATTERNS"; then
  echo "❌ Secret détecté dans les fichiers stagés. Commit refusé."
  exit 1
fi
```

## Doctrine "présentiel uniquement" sur engagements sensibles

Tout échange impliquant l'accès à un secret critique (génération token, partage clé, validation contrat structurant, signature) se fait en présentiel uniquement. Pas de WhatsApp, pas de Slack, pas d'email. Cohérent avec le garde-fou Brief CFO João Almeida.

## Que faire en cas de fuite

1. **Rotation immédiate** du secret compromis (regénération côté provider).
2. **Audit historique git** : `git log -S "<secret-prefix>"` pour identifier les commits exposés.
3. **Si secret exposé sur GitHub public** : `git filter-repo` + force push + alerte GitHub Secret Scanning + invalidation token côté provider.
4. **Post-mortem** : note dans `9_META/06_Doctrine_Sensible/incident-YYYY-MM-DD-<sujet>.md`.

## Suite

- Génération clé GPG : [[gpg-key-generation]]
- Setup vault chiffré : [[obsidian-vault-setup]]
- Décision architecturale fondatrice : [[ADR-001-vault-obsidian-chiffrement-at-rest]]

---

*Doctrine v1.0 — Florent Gibert, 13 mai 2026. À réviser annuellement.*
