---
title: "Stack technologique ONLYMORE Group — mai 2026"
date: 2026-05-13
type: architecture
status: v1.0
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/architecture
  - onlymore/stack
related:
  - "[[_MOC-Architecture-Technique-ONLYMORE]]"
  - "[[repos-github-onlymore]]"
  - "[[secrets-management]]"
---

# Stack technologique ONLYMORE Group — mai 2026

> Snapshot du stack au **13/05/2026**. À mettre à jour à chaque évolution majeure.

## Frontend / Application

| Layer | Choix | Justification |
|---|---|---|
| Framework | Next.js (App Router) | SSR + SSG + edge runtime, écosystème mature |
| Langage | TypeScript strict | Sécurité types, refactoring sûr |
| Styling | Tailwind CSS | Productivité, design tokens via config |
| Composants | Radix UI + shadcn/ui (à confirmer) | Accessibilité + customisation |
| State | React Server Components + Zustand (client) | Côté serveur par défaut, client minimal |

## Backend / Data

| Layer | Choix | Justification |
|---|---|---|
| DB | Supabase (PostgreSQL managé) | Auth + RLS + edge functions intégrés |
| Auth | Supabase Auth | OAuth + email/password + magic links |
| Edge functions | Supabase Edge Functions (Deno) | Proximité DB, low-latency |
| Files | Supabase Storage | Buckets + RLS |
| Cache / queue | TBD — probable Upstash Redis | À évaluer au moment de scale |

## Infrastructure / Deployment

| Layer | Choix |
|---|---|
| Hébergement | Vercel (preview deploys + prod) |
| DNS | Vercel + Cloudflare (TBD long terme) |
| Monitoring | Vercel Analytics + Sentry (à intégrer) |
| Logs | Vercel + Supabase logs |
| CI/CD | GitHub Actions (déclenché par push) |

## Knowledge & Productivity

| Outil | Usage |
|---|---|
| Obsidian | Vault personnel CEO, doctrine, IP |
| git-crypt + GPG | Chiffrement at-rest vault sensible |
| Notion | TODO DB (`88d1d8cb-614b-45b4-be62-e6820d8049d9`), knowledge base partageable |
| Google Workspace | Email pro, calendrier |
| Canva | Design assets, brand kits |

## Automatisation

| Outil | Usage |
|---|---|
| n8n | Workflows (host : `onlymore.app.n8n.cloud`) |
| Claude Code Web | Agents IA, génération doc, scaffolding |
| Composio | OAuth federation (LinkedIn 4 pages, auto-refresh) |

## MCP intégrés (7)

| MCP | Endpoint | Usage principal |
|---|---|---|
| Supabase | MCP local | DB queries, schema, edge functions |
| Vercel | MCP local | Deploys, domains, logs |
| Notion | MCP local | CRUD pages, DB, comments |
| n8n | MCP local | Workflow create/test/execute |
| Gmail | MCP local | Send notifications |
| Canva | MCP local | Generate designs, brand kits |
| Google Calendar | MCP local | Scheduling, reminders |

## Sécurité

| Domaine | Choix |
|---|---|
| Chiffrement at-rest doctrine | git-crypt + GPG RSA 4096 |
| Empreinte GPG master ONLYMORE | `FC622EB8056509B4BBC4B436E47ADD21CC605948` |
| Secrets app | `.env.local` (jamais commité) + Vercel env vars |
| Auth admin | 2FA obligatoire GitHub + Google + Vercel |
| Backup clé GPG | 2 supports physiques distincts (clé USB chiffrée + cloud privé chiffré) |

## Outils dev local Florent (machine Rodilhan)

| Outil | Version |
|---|---|
| OS | Windows 11 |
| Shell | Git Bash |
| Git | bundled Git for Windows |
| GPG | 2.4.9 |
| git-crypt | 0.7.0 (via Scoop) |
| `gh` CLI | latest |
| Obsidian | latest |
| Plugin Obsidian Git | vinzent03 v2.38.2 |
| Scoop | latest |

## Stack par filiale (cible 2026-2027)

| Filiale | Frontend | Backend | Particularité |
|---|---|---|---|
| COLHYBRI | Next.js + Tailwind | Supabase + edge functions | Multi-tenant sociétaires + commerçants |
| CROWNIUM | TBD | TBD | Audit-grade (fan capital flows) |
| DOJUKU SHINGI | React Native (TBD) | Supabase + Runway API | Pipeline vidéo AI-native |
| ONLYMORE FINANCE | TBD | TBD | Conformité IOBSP + ACPR |
| PLUMAYA | Static site (Astro ?) | Supabase | Pipeline éditorial PLUMAYA |

## Décisions architecturales liées

- [[ADR-001-vault-obsidian-chiffrement-at-rest]]
- [[ADR-002-architecture-cascade-mutualiste-spv]]

---

*Stack v1.0 — snapshot 13/05/2026.*
