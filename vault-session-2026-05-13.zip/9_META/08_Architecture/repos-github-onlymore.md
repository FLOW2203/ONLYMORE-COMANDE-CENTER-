---
title: "Cartographie repos GitHub FLOW2203"
date: 2026-05-13
type: architecture
status: v1.0
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/architecture
  - onlymore/github
  - onlymore/repos
related:
  - "[[_MOC-Architecture-Technique-ONLYMORE]]"
  - "[[stack-onlymore-2026-05]]"
  - "[[secrets-management]]"
---

# Cartographie repos GitHub FLOW2203

> État au **13/05/2026**. Tous les repos appartiennent à l'organisation / compte `FLOW2203`.

## Repos actifs

| Repo | Visibilité | Rôle | Stack principale | Statut |
|---|---|---|---|---|
| `ONLYMORE-COMANDE-CENTER-` *(tiret final)* | Privé | Command center / dashboard pilotage groupe, 8 agents IA, 14+ skills, 7 MCP | Next.js + TypeScript + Tailwind + Supabase + Vercel | actif |
| `onlymore-vault` | Privé | Vault Obsidian chiffré at-rest (doctrine, IP, CRM, briefs CFO) | git-crypt + GPG RSA 4096 | actif depuis 13/05/2026 |

## Conventions

### Naming

- Format : `<entity>-<purpose>` ou `<purpose>` direct.
- Tiret final `-` sur `ONLYMORE-COMANDE-CENTER-` : artefact historique conservé pour ne pas casser les références existantes.
- Kebab-case pour les nouveaux repos (`onlymore-vault`, et non `ONLYMORE-VAULT`).

### Branches

- `main` : branche de référence, protégée (PR obligatoire pour merger).
- `feat/*` : features.
- `docs/*` : documentation et runbooks.
- `claude/*` : branches travail Claude Code (préfixe automatique).
- `fix/*` : bugfixes.
- `hotfix/*` : urgences prod.

### PR

- Convention de commit : Conventional Commits (`feat(scope):`, `fix(scope):`, `docs(scope):`, etc.).
- Signature : `Reviewed-by: Florent Gibert <onlymore2024@gmail.com>` en trailer.
- Pas de force-push sur `main`.

## Repos prévisionnels (roadmap, non-créés au 13/05/2026)

| Repo prévu | Rôle anticipé | Échéance |
|---|---|---|
| `colhybri-app` | App principale COLHYBRI (Next.js + Supabase) | Q3 2026 |
| `crownium-infra` | Infrastructure fan capital | Q4 2026 |
| `dojuku-shingi-mobile` | App mobile arts martiaux | 2027 |
| `onlymore-finance-core` | Backend crédit intragroupe | 2027 |
| `plumaya-editions` | Plateforme édition / IP | TBD |
| `onlymore-design-system` | Design tokens + composants partagés filiales | Q3 2026 |

## Accès & permissions

- Owner unique : Florent Gibert (`onlymore2024@gmail.com`).
- Collaborateurs futurs envisagés :
  - João Almeida (CFO) — accès `onlymore-vault` après réunion présentielle (ajout git-crypt user)
  - Michel Nilles (Board Advisor) — accès read-only sur dossiers Constitutions
  - Équipe dev future — accès par filiale, pas accès vault

## GitHub MCP & scope sandbox

Le scope GitHub MCP utilisé en sandbox Claude Code Web est restreint à **`flow2203/onlymore-comande-center-`** uniquement. Toute opération GitHub depuis l'IDE sur `onlymore-vault` se fait **localement** via `gh` CLI sur la machine de Florent.

## Suite

- Stack technologique détaillée : [[stack-onlymore-2026-05]]
- Doctrine secrets : [[secrets-management]]

---

*Cartographie v1.0 — à mettre à jour à chaque création de nouveau repo.*
