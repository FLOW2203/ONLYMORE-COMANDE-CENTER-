---
title: "Map of Content — Architecture Technique ONLYMORE Group"
date: 2026-05-13
type: moc
status: v1.0
author: Florent Gibert
group: ONLYMORE Group
tags:
  - onlymore/moc
  - onlymore/architecture
  - onlymore/stack
related:
  - "[[repos-github-onlymore]]"
  - "[[stack-onlymore-2026-05]]"
  - "[[secrets-management]]"
  - "[[_MOC-Constitutions-Financieres]]"
---

# Map of Content — Architecture Technique ONLYMORE Group

> Point d'entrée unique pour la cartographie technique : repos, stack, secrets, infrastructure.

## Documents de cette collection

| Doc | Objet | Statut |
|---|---|---|
| [[repos-github-onlymore]] | Cartographie de tous les repos GitHub FLOW2203 | v1.0 |
| [[stack-onlymore-2026-05]] | Stack technologique complet au 13/05/2026 | v1.0 |
| [[secrets-management]] | Doctrine secrets, clés, credentials | v1.0 |

## Vue d'ensemble

```
ONLYMORE GROUP — Architecture technique (mai 2026)
│
├── COMMAND CENTER                ← Pilotage stratégique + agents IA
│   └── FLOW2203/ONLYMORE-COMANDE-CENTER-
│       ├── Next.js dashboard
│       ├── 8 agents permanents (ALPHA, FORGE, VAULT, SHIELD,
│       │   HERALD, NEXUS, SENTINEL, TITAN)
│       ├── 14+ skills custom
│       └── 7 MCP intégrés
│
├── DOCTRINE & IP                 ← Vault Obsidian (privé, chiffré at-rest)
│   └── FLOW2203/onlymore-vault
│       ├── PARA 1_PROJECTS → 8_DAILY
│       ├── 9_META/00_CONSTITUTIONS/   🔒 git-crypt
│       ├── 9_META/05_CFO_Briefs/      🔒 git-crypt
│       ├── 9_META/06_Doctrine_Sensible/ 🔒 git-crypt
│       └── 6_CRM/                      🔒 git-crypt
│
├── PRODUITS FILIALES             ← Applications opérationnelles
│   ├── COLHYBRI (SaaS solidarité)         — Next.js + Supabase + Vercel
│   ├── CROWNIUM (fan capital)              — TBD
│   ├── DOJUKU SHINGI (arts martiaux)       — Mobile + Runway pipeline
│   ├── ONLYMORE FINANCE (crédit intragroupe) — TBD
│   └── PLUMAYA (édition)                    — TBD
│
└── INFRA & SECRETS
    ├── GPG RSA 4096 (vault chiffrement)
    ├── 7 MCP : Supabase, Vercel, Notion, n8n, Gmail, Calendar, Canva
    ├── Composio LinkedIn (4 pages, OAuth auto-refresh)
    └── Notion TODO DB (88d1d8cb-614b-45b4-be62-e6820d8049d9)
```

## 8 agents permanents

| Agent | Rôle |
|---|---|
| ALPHA | Strategy & Decision |
| FORGE | Builder & Creator |
| VAULT | Data & Finance |
| SHIELD | Security & Legal |
| HERALD | Communication |
| NEXUS | Integration & Ops |
| SENTINEL | Monitoring & QA |
| TITAN | Infrastructure |

## 7 MCP intégrés

| MCP | Usage |
|---|---|
| Supabase | DB, auth, edge functions |
| Vercel | Deployment, domains, analytics |
| Notion | Knowledge base, TODO DB, editorial calendar |
| n8n | Workflow automation (onlymore.app.n8n.cloud) |
| Gmail | Notifications, outreach |
| Canva | Design assets, brand kits |
| Google Calendar | Scheduling, reminders |

## Liens transverses

- Doctrine financière : [[_MOC-Constitutions-Financieres]]
- Runbooks opérationnels : [[obsidian-vault-setup]], [[gpg-key-generation]], [[git-crypt-install-windows]], [[obsidian-git-plugin-config]]
- Décisions architecturales : [[ADR-001-vault-obsidian-chiffrement-at-rest]] (+ ADR-002 à 005)

---

*MOC institué le 13 mai 2026 — premier point d'entrée architecture du vault.*
